const { test, expect } = require('@playwright/test');

const { LoginPage } = require('../POM/LoginPage');
const { DashboardPage } = require('../POM/DashboardPage');
const { only } = require('node:test');
 
let webContext;
 
test.beforeAll(async ({ browser }) => {
    // session injection
    webContext = await browser.newContext({ storageState: 'Gautam_iocc.json' });
});

//Performing test on date filter
test('Test the functionality of count result for flights for all date filters', async() => {

    const page = await webContext.newPage();

    const login_Page = new LoginPage(page);
    
    await login_Page.goto();

    const dashboardPage = new DashboardPage(page);


    // Login and navigate
    await login_Page.navigate('https://aismartpprd.airindia.com');
    await login_Page.login('app.monitoring@airindia.com');



});
 
test('Login into AirIndia web ---> Today filter should display correct count of flights', async ()  => {

    const page = await webContext.newPage();
    // Create instances of Page Objects
    const login_Page = new LoginPage(page);
    
    await login_Page.goto();

    const dashboardPage = new DashboardPage(page);


    // Login and navigate
    await login_Page.navigate('https://aismartpprd.airindia.com');
    await login_Page.login('app.monitoring@airindia.com');
    
    // const dispatch = await page.locator("Header_NavLinks__Qwol2");
    // await dispatch.click();

   
 
    // Open dashboard and apply filter
    await dashboardPage.openDashboard();

    //await dashboardPage.clickDispatchModule();

    await dashboardPage.selectFilterToday('Today');
 
   // Validate flight counts
    const { totalRecords, cardInnerNumber } = await dashboardPage.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }
        
});
 
test('Tomorrow filter should display correct count of flights', async () => {
    const page = await webContext.newPage();
    const login_Page = new LoginPage(page);
    const dashboardPage = new DashboardPage(page);

     await login_Page.goto();
 
    
    // await login_Page.navigate('https://aismartpprd.airindia.com');
    // await login_Page.login('app.monitoring@airindia.com');
 
    await dashboardPage.openDashboard();
    //await dashboardPage.clickDispatchModule();

    //await expect(page.locator("tomorrowFilter")).toBeVisible();
    await dashboardPage.selectFilterTomorrow('Tomorrow');//Tomorrow
 
    /* const { totalRecords, cardInnerNumber } = await dashboardPage.validateFlightCount();

    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }*/
 
});
 
test('Yesterday filter should display correct count of flights', async () => {
    
    const page = await webContext.newPage();
    const login_Page = new LoginPage(page);
    const dashboardPage = new DashboardPage(page);

    await login_Page.goto();
 
    // await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');
    // await login_Page.login('app.monitoring@airindia.com');
 
    await dashboardPage.openDashboard();
    //await dashboardPage.clickDispatchModule();
    await dashboardPage.selectFilterYesterday('Yesterday');
 
    const { totalRecords, cardInnerNumber } = await dashboardPage.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }
     
});

test('Last 7 Days filter should display correct count of flights', async () => {
    
    const page = await webContext.newPage();
    const login_Page = new LoginPage(page);
    const dashboardPage = new DashboardPage(page);

   await login_Page.goto();
 
    // await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');
    // await login_Page.login('app.monitoring@airindia.com');
 
    await dashboardPage.openDashboard();
    //await dashboardPage.clickDispatchModule();
    await dashboardPage.selectFilterLast7Days('Last 7 days');
 
    const { totalRecords, cardInnerNumber } = await dashboardPage.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }
     
});

test('Last 14 Days filter should display correct count of flights', async () => {
    
    const page = await webContext.newPage();
    const login_Page = new LoginPage(page);
    const dashboardPage = new DashboardPage(page);

    await login_Page.goto();
 
    // await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');
    // await login_Page.login('app.monitoring@airindia.com');
 
    await dashboardPage.openDashboard();
    //await dashboardPage.clickDispatchModule();

    await dashboardPage.selectFilterLast14Days('Last 14 days');
 
    const { totalRecords, cardInnerNumber } = await dashboardPage.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }
     
});