const { test, expect } = require('@playwright/test');
const { TIMEOUT } = require('dns');
let webContext;
// this code is about to login in linkedin
test.beforeAll(async ({ browser }) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    //session injection
    // webContext = await browser.newContext({ storageState: 'jai.json' });
    webContext = await browser.newContext({ storageState: 'Gautam_iocc.json' });
 
    await page.close();
});

//Validate that the Crew details are populated correctly for Captain and First Officer
test('verify crew details for First Officer', async () => {

    const page = await webContext.newPage();
    //await page.pause();

    //console.log('dfsgjhkl ')
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(3000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");

   // const clickViewOption = await page.locator(".MuiBox-root .border-wrapper a[data-bs-target='#OfficerDetails']");

   //Locate the parent container with multiple sub-containers
   const clickMoreButton = await page.locator('.MuiBox-root .border-wrapper a[data-bs-target="#OfficerDetails"]').nth(0);
   await clickMoreButton.click();

   await await page.waitForTimeout(3000);
   await expect(page.getByRole('tab', { name: 'Crew Details' })).toBeVisible();

 

     // Find the First Officer name
    //  const firstOfficerName = await container.getByText('First Officer');
 
       // Click the "More" button
    //    const moreButton = await page.locator("d-flex align-items-center px-3 py-2").nth(0);
    //    const content = await moreButton.textContent();
    //    console.log(content);

    // const paginationLocator = page.locator("d-flex align-items-center px-3 py-2").nth(0);
    const paginationLocator = page.locator("[class='p-0 mb-0']"); // Replace with your actual selector

    const count = await paginationLocator.count();
    if (count === 0) {
  
    const paginationElements = await paginationLocator.elementHandles(); // Get all element handles
    const paginationText = await Promise.all(paginationElements.map(element => element.textContent()));
    console.log(paginationText);
    console.error("No pagination elements found");
} else {
    // Get text content from all pagination elements
    const paginationElements = await paginationLocator.elementHandles();
    const paginationText = await Promise.all(paginationElements.map(element => element.textContent()));

    // Flatten the paginationText array and trim whitespace
    const flatPaginationText = paginationText.map(text => text.trim());

    // Define the expected content
    const expectedContent = [
        'Basic Details',
        'DEL',
        'Designation',
        'FIRST OFFICER',
        'Fleet',
        '787',
        'Contact Details',
        'Phone',
        '918800743776',
        'Email ID',
        'ezan.hussain@airindia.com',
        'Address',
        'PURANI ABKARI BAMBAGHER, RAMNAGAR NAINITAL, , IN',
        'Passport Details',
        'Passport Issue Date',
        '2016-08-15',
        'Passport No.',
        'P3221513',
        'Passport Expiry Date',
        '2026-08-15',
        'Nationality',
        'IN',
        'Qualifications',
        'Category Qualification',
        'IIIB_P2787/II_P2787',
        'Fleet Qualification',
        '787',
        'Critical Airfield Qualification'
    ];

    // Check for mismatches
    const mismatchedItems = flatPaginationText.filter(item => !expectedContent.includes(item));
    
    if (mismatchedItems.length === 0) {
        console.log('All expected items found');
    } else {
        console.log(`Mismatched items: ${mismatchedItems.join(', ')}`);
    }
}

    });


    test('verify Rooster details for First Officer', async () => {

        const page = await webContext.newPage();
        //await page.pause();
    
        //console.log('dfsgjhkl ')
        const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
        await page.waitForLoadState('domcontentloaded');
        await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
        await page.getByRole('button', { name: 'Sign In' }).click();
    
        await page.waitForTimeout(3000);
        await page.waitForLoadState('load');
        //await page.waitForLoadState("networkidle")
        await page.waitForTimeout(3000)
        //await page.waitForLoadState("load")
        await page.waitForLoadState('domcontentloaded');
        await page.goto('https://aismartpprd.airindia.com/DispatchModule');
        await page.waitForTimeout(3000);
        console.log("Dispatch Module Dashboard has been opened");
    
       // const clickViewOption = await page.locator(".MuiBox-root .border-wrapper a[data-bs-target='#OfficerDetails']");
    
       //Locate the parent container with multiple sub-containers
       const clickMoreButton = await page.locator('.MuiBox-root .border-wrapper a[data-bs-target="#OfficerDetails"]').nth(0);
       await clickMoreButton.click();
    
       await await page.waitForTimeout(3000);
       await expect(page.getByRole('tab', { name: 'Roster' })).toBeVisible();
    
     
    
         // Find the First Officer name
        //  const firstOfficerName = await container.getByText('First Officer');
     
           // Click the "More" button
        //    const moreButton = await page.locator("d-flex align-items-center px-3 py-2").nth(0);
        //    const content = await moreButton.textContent();
        //    console.log(content);
    
        // const paginationLocator = page.locator("d-flex align-items-center px-3 py-2").nth(0);
        const paginationLocator = page.locator("[class='roaster']"); // Replace with your actual selector
    
        // const count = await paginationLocator.count();
        // if (count === 0) {
      
        const paginationElements = await paginationLocator.elementHandles(); // Get all element handles
        const paginationText = await Promise.all(paginationElements.map(element => element.textContent()));
        console.log(paginationText);
    //     console.error("No pagination elements found");
    // } else {
    //     // Get text content from all pagination elements
    //     const paginationElements = await paginationLocator.elementHandles();
    //     const paginationText = await Promise.all(paginationElements.map(element => element.textContent()));
    
    //     // Flatten the paginationText array and trim whitespace
    //     const flatPaginationText = paginationText.map(text => text.trim());
    
    //     // Define the expected content
    //     const expectedContent = [
    //         'Basic Details',
    //         'DEL',
    //         'Designation',
    //         'FIRST OFFICER',
    //         'Fleet',
    //         '787',
    //         'Contact Details',
    //         'Phone',
    //         '918800743776',
    //         'Email ID',
    //         'ezan.hussain@airindia.com',
    //         'Address',
    //         'PURANI ABKARI BAMBAGHER, RAMNAGAR NAINITAL, , IN',
    //         'Passport Details',
    //         'Passport Issue Date',
    //         '2016-08-15',
    //         'Passport No.',
    //         'P3221513',
    //         'Passport Expiry Date',
    //         '2026-08-15',
    //         'Nationality',
    //         'IN',
    //         'Qualifications',
    //         'Category Qualification',
    //         'IIIB_P2787/II_P2787',
    //         'Fleet Qualification',
    //         '787',
    //         'Critical Airfield Qualification'
    //     ];
    
    //     // Check for mismatches
    //     const mismatchedItems = flatPaginationText.filter(item => !expectedContent.includes(item));
        
    //     if (mismatchedItems.length === 0) {
    //         console.log('All expected items found');
    //     } else {
    //         console.log(`Mismatched items: ${mismatchedItems.join(', ')}`);
    //     }
    // }
    
        });

        //.MuiBox-root .border-wrapper a[data-bs-target="#captainDetail"]  

        test('verify crew details for Captain', async () => {

            const page = await webContext.newPage();
            //await page.pause();
        
            //console.log('dfsgjhkl ')
            const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
            await page.waitForLoadState('domcontentloaded');
            await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
            await page.getByRole('button', { name: 'Sign In' }).click();
        
            await page.waitForTimeout(3000);
            await page.waitForLoadState('load');
            //await page.waitForLoadState("networkidle")
            await page.waitForTimeout(3000)
            //await page.waitForLoadState("load")
            await page.waitForLoadState('domcontentloaded');
            await page.goto('https://aismartpprd.airindia.com/DispatchModule');
            await page.waitForTimeout(3000);
            console.log("Dispatch Module Dashboard has been opened");
        
           // const clickViewOption = await page.locator(".MuiBox-root .border-wrapper a[data-bs-target='#OfficerDetails']");
        
           //Locate the parent container with multiple sub-containers
           const clickMoreButton = await page.locator(".MuiBox-root .border-wrapper a[data-bs-target='#captainDetail']").nth(0);
           await clickMoreButton.click();
        
           await await page.waitForTimeout(3000);
           await expect(page.getByRole('tab', { name: 'Crew Details' })).toBeVisible();
        
         
        
             // Find the First Officer name
            //  const firstOfficerName = await container.getByText('First Officer');
         
               // Click the "More" button
            //    const moreButton = await page.locator("d-flex align-items-center px-3 py-2").nth(0);
            //    const content = await moreButton.textContent();
            //    console.log(content);
        
            // const paginationLocator = page.locator("d-flex align-items-center px-3 py-2").nth(0);
            const paginationLocator = page.locator("[class='p-0 mb-0']").nth(1); 
            const count = await paginationLocator.count();
            if (count === 0) {
          
            const paginationElements = await paginationLocator.elementHandles(); // Get all element handles
            const paginationText = await Promise.all(paginationElements.map(element => element.textContent()));
            console.log(paginationText);
            console.error("No pagination elements found");
        } else {
            // Get text content from all pagination elements
            const paginationElements = await paginationLocator.elementHandles();
            const paginationText = await Promise.all(paginationElements.map(element => element.textContent()));
        
            // Flatten the paginationText array and trim whitespace
            const flatPaginationText = paginationText.map(text => text.trim());
        
            // Define the expected content
            const expectedContent = [
                'Basic Details',
                'DEL',
                'Designation',
                'FIRST OFFICER',
                'Fleet',
                '787',
                'Contact Details',
                'Phone',
                '918800743776',
                'Email ID',
                'ezan.hussain@airindia.com',
                'Address',
                'PURANI ABKARI BAMBAGHER, RAMNAGAR NAINITAL, , IN',
                'Passport Details',
                'Passport Issue Date',
                '2016-08-15',
                'Passport No.',
                'P3221513',
                'Passport Expiry Date',
                '2026-08-15',
                'Nationality',
                'IN',
                'Qualifications',
                'Category Qualification',
                'IIIB_P2787/II_P2787',
                'Fleet Qualification',
                '787',
                'Critical Airfield Qualification'
            ];
        
            // Check for mismatches
            const mismatchedItems = flatPaginationText.filter(item => !expectedContent.includes(item));
            
            if (mismatchedItems.length === 0) {
                console.log('All expected items found');
            } else {
                console.log(`Mismatched items: ${mismatchedItems.join(', ')}`);
            }
        }
        
            });


 


