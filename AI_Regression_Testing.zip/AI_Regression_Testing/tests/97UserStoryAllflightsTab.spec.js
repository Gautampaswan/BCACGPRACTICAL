const { test, expect } = require('@playwright/test');
const { TIMEOUT } = require('dns');
let webContext;
// this code is about to login in linkedin
test.beforeAll(async ({ browser }) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    //session injection
    // webContext = await browser.newContext({ storageState: 'jai.json' });
    webContext = await browser.newContext({ storageState: 'Gautam_iocc.json' });
 
    await page.close();
});
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

//Verify that if the user selects the filter for “Today”, then user should be able to view the count result as per the filter selected in "ALL Flights"
test.only('Test filter for Today in All flights', async () => {
  
    const page = await webContext.newPage();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000)

    //await page.waitForLoadState('network');
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    console.log("Dispatch Module Dashboard has been opened");
    //await page.locator("//button[text()= 'All Flights']").click();
    
    //Select Filter dropdown
     await page.locator("img[alt='Not Found']").nth(3).click();
     await page.locator("//a[text()= 'Today']").click();

     await page.waitForTimeout(3000);
     //Validate total flights
     const paginationLocator = page.locator("div[class='pagePagination d-flex justify-content-between mt-5 ps-2 align-items-center'] div p");
  
    // Get the full text from the pagination element
    const paginationText = await paginationLocator.textContent();
    console.log("Extracted Pagination Text:", paginationText);
 
       // Extract the number between "of" and "records" using regex
       const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
       if (paginationMatch) {
        const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
        console.log("Total Records (from pagination):", totalRecords);
 
        // Locate the element with class 'card-inner' and extract its number
        const cardInnerLocator = page.locator('text-primarry fw-600 mt-2 d-flex align-items-center gap-2').nth(0);
        const cardInnerText = await cardInnerLocator.textContent();
        console.log("Extracted Card Inner Text:", cardInnerText);
 
        // Extract the number from the 'card-inner' text using regex (assuming it's a number)
        const cardInnerMatch = cardInnerText.match(/(\d+)/);
 
        if (cardInnerMatch) {
            const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
            console.log("Extracted Number (from card-inner):", cardInnerNumber);
 
            // Compare total records and cardInnerNumber
            if (cardInnerNumber === totalRecords) {
                console.log("Numbers match! Test passed.");
            } else {
                console.log("Numbers do not match. Test failed.");
            }
 
            // You can also add an assertion for this comparison if required
            expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
        } else {
            console.log("Could not extract number from 'card-inner'.");
        }
    } else {
        console.log("Could not find the number in the pagination text.");
    }
        await page.pause();
 
});

     //Verify that if the user selects the filter for “Yesterday”, then user should be able to view the count result as per the filter selected in "ALL Flights"
test('“Test filter for Yesterday”', async () => {

    const page = await webContext.newPage();
 
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000)

    //await page.waitForLoadState('load');
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    console.log("Dispatch Module Dashboard has been opened");
 
      await page.locator("img[alt='Not Found']").nth(3).click();
      await page.waitForTimeout(3000);
      await page.locator("//a[text()= 'Yesterday']").click();
  
     //await page.waitForLoadState(network);
     await page.waitForTimeout(3000);

     //Validate counts of flights
     const paginationLocator = page.locator("div[class='pagePagination d-flex justify-content-between mt-5 ps-2 align-items-center'] div p");
  
      // Get the full text from the pagination element
      const paginationText = await paginationLocator.textContent();
      console.log("Extracted Pagination Text:", paginationText);

      // Extract the number between "of" and "records" using regex
       const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
      if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);


      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);

      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);

      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);

          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Numbers do not match. Test failed.");
          }

          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); 
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
     await page.pause();
});

      //Verify that if the user selects the filter for “Tomorrow”, then user should be able to view the count result as per the filter selected in "ALL Flights
test('Test filter for Tomorrow in all flights ', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");

    await page.locator("img[alt='Not Found']").nth(3).click();
    await page.waitForTimeout(3000);
    await page.locator("//a[text()= 'Tomorrow']").click();

    //await page.waitForLoadState(network);
     await page.waitForTimeout(3000);

     //Validate total flight count
     const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
    // Get the full text from the pagination element
      const paginationText = await paginationLocator.textContent();
      console.log("Extracted Pagination Text:", paginationText);

      // Extract the number between "of" and "records" using regex
       const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
       if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);


      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);

      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);

      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);

          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Numbers do not match. Test failed.");
          }

          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords);
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
   await page.pause();
  

});

//Verify that if the user selects the filter for “Last 7 days”, then user should be able to view the count result as per the filter selected in "All Flights".
test('Test filter for Last 7 days in all flights', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");

    await page.locator("img[alt='Not Found']").nth(3).click();
    await page.locator("//a[text()= 'Last 7 days']").click();
       //await page.locator("//button[text()= 'All Flights']").click();
       await page.waitForTimeout(3000);

       //Validate total flight count
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
      // Get the full text from the pagination element
       const paginationText = await paginationLocator.textContent();
       console.log("Extracted Pagination Text:", paginationText);

       // Extract the number between "of" and "records" using regex
       const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
        if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);


      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);

      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);

      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);

          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Numbers do not match. Test failed.");
          }

          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
              await page.pause();

});

    //Verify that if the user selects the filter for “Last 14 days”, then user should be able to view the count result as per the filter selected in "All Flights"
test('Test filter for Last 14 days in all flights', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);

    console.log("Dispatch Module Dashboard has been opened");
    await page.locator("img[alt='Not Found']").nth(3).click();
    await page.locator("//a[text()= 'Last 14 days']").click();

     await page.waitForTimeout(3000);


   const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
  // Get the full text from the pagination element
  const paginationText = await paginationLocator.textContent();
  console.log("Extracted Pagination Text:", paginationText);

  // Extract the number between "of" and "records" using regex
  const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
  if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);


      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);

      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);

      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);

          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Numbers do not match. Test failed.");
          }

          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
         await page.pause();

});

     //Verify that if the user selects the filter for  stations “Any one station ” then user should be able to view the count result as per the filter selected in "All flights".//296956
test('Test filter  for SelectAny Station in all flights ', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);

    console.log("Dispatch Module Dashboard has been opened");

   await page.waitForTimeout(3000);
   const dropdownicon = await page.locator(".dpArrows img");
   await dropdownicon.click();
   //Uncheck All Airport option
   //dropdown await page.getByRole('button', { name: 'All Airports' }).click();
   const uncheckAllairport = await page.getByLabel('All Airports')//uncheck();
   await uncheckAllairport.uncheck();
   //Select any Station from dropdown
   const checkAnystation = await page.getByLabel('BLR');
   await checkAnystation.click();

   //Check if station counts are equal or not
    await page.waitForTimeout(3000);
    const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");

    // Get the full text from the pagination element
    await page.waitForTimeout(3000);
   const paginationText = await paginationLocator.textContent();
   console.log("Extracted Pagination Text:", paginationText);

    // Extract the number between "of" and "records" using regex
    const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
    if (paginationMatch) {
    const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
    console.log("Total Records (from pagination):", totalRecords);


    // Locate the element with class 'card-inner' and extract its number
    const cardInnerLocator = page.locator('.card-inner').nth(0);
    const cardInnerText = await cardInnerLocator.textContent();
    console.log("Extracted Card Inner Text:", cardInnerText);

    // Extract the number from the 'card-inner'
    const cardInnerMatch = cardInnerText.match(/(\d+)/);

     if (cardInnerMatch) {
        const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
        console.log("Extracted Number (from card-inner):", cardInnerNumber);

        // Compare total records and cardInnerNumber
        if (cardInnerNumber === totalRecords) {
            console.log("Numbers match! Test passed.");
        } else {
            console.log("Total Flights matched do not match. Test failed.");
        }

        // You can also add an assertion for this comparison if required
        expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
    } else {
            console.log("Could not extract number from 'card-inner'.");
    }
}  else {
            console.log("Could not find the number in the pagination text.");
}
              await page.pause();


});
      



//Verify that if the user selects the filter for  stations “More than one  station ” stations then user should be able to view the count result as per the filter selected in "All Flights"
test('Test filter for Morethan one Station', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);

    console.log("Dispatch Module Dashboard has been opened");
   
     await page.waitForTimeout(3000);
     const dropdownicon = await page.locator(".dpArrows img");
     await dropdownicon.click();

     //Uncheck All Airport option
     const uncheckAllairport = await page.getByLabel('All Airports')//uncheck();
     await uncheckAllairport.uncheck();
     //Select any Station from dropdown
     const checkAnystation = await page.getByLabel('BLR');
     await checkAnystation.click();
     const checkTwostations = await page.getByLabel('GAU')//check();
     await checkTwostations.click();
    //Check if station counts are equal or not
      await page.waitForTimeout(3000);
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
  // Get the full text from the pagination element
  const paginationText = await paginationLocator.textContent();
  console.log("Extracted Pagination Text:", paginationText);
  
  // Extract the number between "of" and "records" using regex
  const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
  if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);

      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
         await page.pause();
  
  
  });

  //Verify that if the user selects the filter for  stations “All  stations ” stations then user should be able to view the count result as per the filter selected in "All Flights"
  test('Test filter for Select All Stations', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");
  
     await page.waitForTimeout(3000);
     const dropdownicon = await page.locator(".dpArrows img");
     await dropdownicon.click();
    //Check if station counts are equal or not
      await page.waitForTimeout(3000);
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
      // Get the full text from the pagination element
       const paginationText = await paginationLocator.textContent();
       console.log("Extracted Pagination Text:", paginationText);
  
       // Extract the number between "of" and "records" using regex
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
           if (paginationMatch) {
              const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
              console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
        await page.pause();
  
  });


  //Verify that user can see count result when searched by full flightNo (Ex AI678) in "All Flgihts"

test('Test Search by full flight number in All flights tab', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");
  
    const searchflightbox = await page.locator("input[name='Search_Flight']");
    await searchflightbox.click();

    //Type flight number
     await page.waitForTimeout(3000);
     await searchflightbox.fill("AI804");
     await page.waitForTimeout(3000);
     await page.keyboard.press('Enter');
     await expect(page.getByText('AI804').first()).toContainText('AI804');
     await page.waitForTimeout(3000);

      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
      // Get the full text from the pagination element
       const paginationText = await paginationLocator.textContent();
       console.log("Extracted Pagination Text:", paginationText);
  
       // Extract the number between "of" and "records" using regex
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
           if (paginationMatch) {
              const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
              console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
        await page.pause();
  
  });

    //************ Not Working **************//
   //Verify that user can see the count result when searched By partial flightNo (Ex 678) in "All Flgihts".//Test Search by full flight number in All flights tab

  /*test('Test Search by partial flight number in All flights tab', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");
  
    const searchflightbox = await page.locator("input[name='Search_Flight']");
    await searchflightbox.click();

    //Type flight number
     await page.waitForTimeout(3000);
     await searchflightbox.fill("AI8");
     await page.waitForTimeout(3000);
     await page.keyboard.press('Enter');
     await expect(page.getByText('AI8').first()).toContainText('AI8');
     await page.waitForTimeout(3000);

      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
      // Get the full text from the pagination element
       const paginationText = await paginationLocator.textContent();
       console.log("Extracted Pagination Text:", paginationText);
  
       // Extract the number between "of" and "records" using regex
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
           if (paginationMatch) {
              const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
              console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
        await page.pause();
  
  });*/


  ///Verify that user can see the count result as per Search By full TailNo (Ex VT-AXN) in "All Flights".

  test('Test Search by full Tail number in All flights tab', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");
  
    const searchflightbox = await page.locator("input[name='Search_Flight']");
    await searchflightbox.click();

    //Type Tail number number
     await page.waitForTimeout(3000);
     await searchflightbox.fill("VT-EXG");
     await page.waitForTimeout(3000);
     await page.keyboard.press('Enter');
     await expect(page.getByText('VT-EXG').first()).toContainText('VT-EXG');
     await page.waitForTimeout(3000);

      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
       // Get the full text from the pagination element
       const paginationText = await paginationLocator.textContent();
       console.log("Extracted Pagination Text:", paginationText);
  
        // Extract the number between "of" and "records" using regex
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
           if (paginationMatch) {
              const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
              console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
        await page.pause();
  
  });


  //Verify that user can count result  as per Search By partial TailNo (Ex AXN) in "All Flights".

  test('Test Search by partial Tail number in All flights tab', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");
  
    const searchflightbox = await page.locator("input[name='Search_Flight']");
    await searchflightbox.click();

    //Type Tail partial number number
     await page.waitForTimeout(3000);
     await searchflightbox.fill("VT-E");
     await page.waitForTimeout(3000);
     await page.keyboard.press('Enter');
     await expect(page.getByText('VT-E').first()).toContainText('VT-E');
     await page.waitForTimeout(3000);

      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
       // Get the full text from the pagination element
       const paginationText = await paginationLocator.textContent();
       console.log("Extracted Pagination Text:", paginationText);
  
        // Extract the number between "of" and "records" using regex
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
           if (paginationMatch) {
              const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
              console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
        await page.pause();
  
  });



 