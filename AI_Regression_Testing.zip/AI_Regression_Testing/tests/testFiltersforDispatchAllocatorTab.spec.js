const { test, expect } = require('@playwright/test');

const { LoginPage } = require('../POM/LoginPage');
const { allocateDispatch } = require('../POM/allocateDispatch');
const { only } = require('node:test');
const { count } = require('console');
 
let webContext;
 
test.beforeAll(async ({ browser }) => {
    // session injection
    webContext = await browser.newContext({ storageState: 'Gautam_iocc.json' });
});
 
test('Login into AirIndia web ---> Today filter should display correct count of flights', async ()  => {
    const page = await webContext.newPage();
    
    // Create instances of Page Objects
    const login_Page = new LoginPage(page); 
    await login_Page.goto();

    const dispatchTab = new allocateDispatch(page);

    // Login and navigate
     await login_Page.login('app.monitoring@airindia.com');
    // await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');
 
    // Open dashboard and apply filter
    await dispatchTab.openDashboard();


    
    //click Dispatch Module Option at middle top of the page
    await dispatchTab.clickdispatchModule();

    //Click on allocate dispatcher tab
    await dispatchTab.clickAllocateDispatcherTab();

    //Select date filter for today
    await dispatchTab.selectFilterforToday('Today');
 
    // Validate flight counts
    const { totalRecords, cardInnerNumber } = await dispatchTab.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }
        
});
 
test('Tomorrow filter should display correct count of flights', async () => {
    const page = await webContext.newPage();
    
    // Create instances of Page Objects
    const login_Page = new LoginPage(page); 
    await login_Page.goto();

    const dispatchTab = new allocateDispatch(page);

    // Login and navigate
     await login_Page.login('app.monitoring@airindia.com');
    // await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');
 
    // Open dashboard and apply filter
    await dispatchTab.openDashboard();


    
    //click Dispatch Module Option at middle top of the page
    await dispatchTab.clickdispatchModule();

    //Click on allocate dispatcher tab
    await dispatchTab.clickAllocateDispatcherTab();

      await dispatchTab.selectFilterforTomorrow('Tomorrow');
 
    const { totalRecords, cardInnerNumber } = await dispatchTab.validateFlightCount();

    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }
 
});
 
test('Yesterday filter should display correct count of flights', async () => {
    //login to page
    const login_Page = new LoginPage(page); 
    await login_Page.goto();

    const dispatchTab = new allocateDispatch(page);
 
    await login_Page.login('app.monitoring@airindia.com');
    //await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');
 
    await dispatchTab.openDashboard();

      //click Dispatch Module Option at middle top of the page
      await dispatchTab.clickdispatchModule();

      //Click on allocate dispatcher tab
      await dispatchTab.clickAllocateDispatcherTab();

    //Select date filter for yesterday
    await dispatchTab.selectFilterforYesterday('Yesterday');
 
    const { totalRecords, cardInnerNumber } = await dispatchTab.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }
     
});

test('Last 7 Days filter should display correct count of flights', async () => {
    
    const page = await webContext.newPage();
    const login_Page = new LoginPage(page);
    const dispatchTab = new allocateDispatch(page);
    await login_Page.goto();
 
    await login_Page.login('app.monitoring@airindia.com');
    //await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');
 
    await dispatchTab.openDashboard();

     //click Dispatch Module Option at middle top of the page
     await dispatchTab.clickdispatchModule();

     //Click on allocate dispatcher tab
     await dispatchTab.clickAllocateDispatcherTab();

    //Select date filter for Last 7 days filters
    await dispatchTab.selectFilterforLast7Days('Last 7 days');
 
    const { totalRecords, cardInnerNumber } = await dispatchTab.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }
     
});

test('Last 14 Days filter should display correct count of flights', async () => {
    
    const page = await webContext.newPage();
    const login_Page = new LoginPage(page);
    const dispatchTab = new allocateDispatch(page);

    await login_Page.goto();
 
    await login_Page.login('app.monitoring@airindia.com');
    //await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');
 
    await dispatchTab.openDashboard();

    //click Dispatch Module Option at middle top of the page
    await dispatchTab.clickdispatchModule();

    //Click on allocate dispatcher tab
    await dispatchTab.clickAllocateDispatcherTab();

    //select filter for Last 14 days
    await dispatchTab.selectFilterforLast14Days('Last 14 days');
 
    const { totalRecords, cardInnerNumber } = await dispatchTab.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }
     
});

//Verify that if the user selects the filter for  stations “Any one station ” then user should be able to view the count result as per the filter selected in "All Flights".******///

test('Count resul for total flights for Any station', async () => {

    const page = await webContext.newPage();
    const login_Page = new LoginPage(page);
    const dispatchTab = new allocateDispatch(page);
    await login_Page.goto();

    await login_Page.login('app.monitoring@airindia.com');
    //await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');

    await dispatchTab.openDashboard();

    //click Dispatch Module Option at middle top of the page
    await dispatchTab.clickdispatchModule();

    //Click on allocate dispatcher tab
    await dispatchTab.clickAllocateDispatcherTab();

    //Tick checkbox for only one station under Airports dropdown located at top right hand side of the page
    await dispatchTab.selectCheckboxForOneStation();

    const { totalRecords, cardInnerNumber } = await dispatchTab.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }

});

//Verify that if the user selects the filter for  stations “More than one  station ” stations then user should be able to view the count result as per the filter selected in "All Flights"
test('Test count result for morethan one station', async() => {

    const page = await webContext.newPage();
    const login_Page = new LoginPage(page);
    const dispatchTab = new allocateDispatch(page);

    await login_Page.goto();
    await login_Page.login('app.monitoring@airindia.com');
    //await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');

    await dispatchTab.openDashboard();

    //click Dispatch Module Option at middle top of the page
    await dispatchTab.clickdispatchModule();

    //Click on allocate dispatcher tab
    await dispatchTab.clickAllocateDispatcherTab();

    //Select checkbox for morethan one station 
    await dispatchTab.morethanoneStation();

    const { totalRecords, cardInnerNumber } = await dispatchTab.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }

});

//***********Verify that if the user selects the filter for  stations “All  stations ” stations then user should be able to view the count result as per the filter selected in "All Flights"**********************//

test('Test total flight counts for ALl stations', async() => {

    const page = await webContext.newPage();
    const login_Page = new LoginPage(page);
    const dispatchTab = new allocateDispatch(page);

    await login_Page.goto();
    await login_Page.login('app.monitoring@airindia.com');
    //await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');

    await dispatchTab.openDashboard();

    //click Dispatch Module Option at middle top of the page
    await dispatchTab.clickdispatchModule();

    //Click on allocate dispatcher tab
    await dispatchTab.clickAllocateDispatcherTab();

    //Select checkbox for all station
    await dispatchTab.selectallStations();

    const { totalRecords, cardInnerNumber } = await dispatchTab.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }

});

    //*******Verify that user can see count result when searched by full flightNo (Ex AI678) in "All Flgihts"******//

    test('Search by full flight number', async() => {


        const page = await webContext.newPage();
        const login_Page = new LoginPage(page);
        const dispatchTab = new allocateDispatch(page);
    
        await login_Page.goto();

        await login_Page.login('app.monitoring@airindia.com');
        //await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');

        await dispatchTab.openDashboard();

        //click Dispatch Module Option at middle top of the page
       await dispatchTab.clickdispatchModule();

     //Click on allocate dispatcher tab
       await dispatchTab.clickAllocateDispatcherTab();

        //search for by entering full flight number under search flight box.
        await dispatchTab.searchByPartialtailNumber();

        const { totalRecords, cardInnerNumber } = await dispatchTab.validateFlightCount();
        if (totalRecords && cardInnerNumber) {
            expect(cardInnerNumber).toBe(totalRecords);
            console.log("Numbers match! Test passed.");
        } else {
            console.log("Test failed. Could not validate flight counts.");
        }

    });

    //Verify that user can see the count result as per Search By full TailNo (Ex VT-AXN) in "All Flights".

    test('Search by full tail number', async() => {


        const page = await webContext.newPage();
        const login_Page = new LoginPage(page);
        const dispatchTab = new allocateDispatch(page);
    
        await login_Page.goto();
        await login_Page.login('app.monitoring@airindia.com');
        //await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');

        await dispatchTab.openDashboard();

        //click Dispatch Module Option at middle top of the page
        await dispatchTab.clickdispatchModule();

       //Click on allocate dispatcher tab
        await dispatchTab.clickAllocateDispatcherTab();

        //search by entering full tail number
        await dispatchTab.searchbyfullTailNumber();

        const { totalRecords, cardInnerNumber } = await dispatchTab.validateFlightCount();
        if (totalRecords && cardInnerNumber) {
            expect(cardInnerNumber).toBe(totalRecords);
            console.log("Numbers match! Test passed.");
        } else {
            console.log("Test failed. Could not validate flight counts.");
        }

    });

    //Verify that user can count result  as per Search By partial TailNo (Ex AXN) in "All Flights".

    test('Search by partial tail number', async() => {


        const page = await webContext.newPage();
        const login_Page = new LoginPage(page);
        const dispatchTab = new allocateDispatch(page);
    
        await login_Page.goto();
        await login_Page.login('app.monitoring@airindia.com');
        //await login_Page.navigate('https://aismartpprd.airindia.com/DispatchModule');  

        await dispatchTab.openDashboard();

        //click Dispatch Module Option at middle top of the page
         await dispatchTab.clickdispatchModule();

        //Click on allocate dispatcher tab
        await dispatchTab.clickAllocateDispatcherTab();
        //Search by entering partial tail number
        await dispatchTab.searchByPartialtailNumber();

        const { totalRecords, cardInnerNumber } = await dispatchTab.validateFlightCount();
        if (totalRecords && cardInnerNumber) {
            expect(cardInnerNumber).toBe(totalRecords);
            console.log("Numbers match! Test passed.");
        } else {
            console.log("Test failed. Could not validate flight counts.");
        }

    });