const { test, expect } = require('@playwright/test');
let webContext;
 
test.beforeAll(async ({ browser }) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    await page.goto('https://login.microsoftonline.com/');
    await page.getByPlaceholder('Email, phone, or Skype').click();
    await page.getByPlaceholder('Email, phone, or Skype').fill('c_gautam.paswan1@partners.airindia.com');
    await page.getByRole('button', { name: 'Next' }).click();
    await page.getByPlaceholder('Password').click();
    await page.getByPlaceholder('Password').fill('Pass@#$123456');
   
    await page.getByRole('button', { name: 'Sign in' }).click();
 
  await page.waitForTimeout(30999)
  await page.goto('https://aismartpprd.airindia.com/');
  await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  await page.getByRole('button', { name: 'Sign In' }).click();
  await page.locator('[type="submit"]').click();
  await page.waitForTimeout(40999)
 
    //session store
    await context.storageState({ path: 'Gautam_iocc.json' });
    //session injection
    webContext = await browser.newContext({ storageState: 'Gautam_iocc.json' });
    await page.close();
});
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
test('Create token', async () => {
    const page = await webContext.newPage();
   
    await page.goto('https://aismartpprd.airindia.com');
    await page.waitForLoadState('domcontentloaded');
    await page.waitForLoadState('load');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
 
    await page.pause();
 
});