const { assert } = require("console");

// DashboardPage.js
class DashboardPage {
    
    constructor(page) {
        
        this.page = page;

        this.clickDispatch = page.locator("//a[text()='Dispatch Module']")
        //Click on the Date Filter Dropdwon
        this.flightFilterIcon = page.locator("img[alt='Not Found']").nth(3);

        this.todayFilter = page.locator("//a[text()='Today']");

        this.tomorrowFilter = page.locator("//a[text()='Tomorrow']");

        this.yesterdayFilter = page.locator("//a[text()='Yesterday']");

        this.last7DaysFilter = page.locator("//a[text()='Last 7 days']");

        this.last14DaysFilter = page.locator("//a[text()='Last 14 days']");

       this.paginationLocator = page.locator("div[class='pagePagination d-flex justify-content-between mt-5 ps-2 align-items-center'] div p");

      this.cardInnerLocator = page.locator('.card-inner').nth(0);

        // this.dispatchtabTop = page.locator("//a[text()= 'Dispatch Module']");

       // ***********************************************************************
        //***********************************************************************
       /* this.paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");

        this.cardInnerLocator = page.locator('.card-inner').nth(0);*/

        // this.dispatchtabTop = page.locator("//a[text()= 'Dispatch Module']");
    }
 
    async openDashboard() {
        console.log("Dispatch Module Dashboard has been opened");
        await this.page.waitForTimeout(5000);
    }

    // async clickDispatchModule(){
    //     await  this.clickDispatch.click();
    // }
 
    async selectFilterToday() {
        await this.page.waitForTimeout(5000);
        await this.clickDispatch.click();
        await this.page.waitForTimeout(5000);
        await this.flightFilterIcon.click();
        await this.todayFilter.click();
        await this.page.waitForTimeout(5000);
        return await this.validateFlightCount();
    }

    async selectFilterTomorrow() {

        await this.page.waitForTimeout(5000);
        await this.clickDispatch.click();
        await this.page.waitForTimeout(5000);
        await this.flightFilterIcon.click();
        await this.page.waitForLoadState("networkidle");
        await this.tomorrowFilter.click();
        await this.page.waitForTimeout(5000);
        return await this.validateFlightCount();
       
    }
        
    async selectFilterYesterday() {

        await this.page.waitForTimeout(5000);
        await this.clickDispatch.click();
        await this.page.waitForTimeout(5000);
        await this.flightFilterIcon.click();
        await this.yesterdayFilter.click();
        await this.page.waitForTimeout(5000);
        return await this.validateFlightCount();
    }

    async selectFilterLast7Days() {
        await this.page.waitForTimeout(5000);
        await this.clickDispatch.click();
        await this.page.waitForTimeout(5000);
        await this.flightFilterIcon.click();      
        await this.last7DaysFilter.click();
        await this.page.waitForTimeout(5000);
        return await this.validateFlightCount();

    }

    async selectFilterLast14Days() {

        await this.page.waitForTimeout(5000);
        await this.clickDispatch.click();
        await this.page.waitForTimeout(5000);
        await this.flightFilterIcon.click();
        await this.last14DaysFilter.click();
        await this.page.waitForTimeout(5000);
        return await this.validateFlightCount();

    }
    // //For login page
    // async goto() {

    //     await this.page.waitForTimeout(3000);
    //     await this.page.goto('https://aismartpprd.airindia.com/DispatchModule');
    // }
 
    async validateFlightCount() {
        // Extract and compare flight counts
        const paginationText = await this.paginationLocator.textContent();
        console.log("Extracted Pagination Text:", paginationText);
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
        if (paginationMatch) {
            const totalRecords = parseInt(paginationMatch[1]);
            console.log("Total Records (from pagination):", totalRecords);
            const cardInnerText = await this.cardInnerLocator.textContent();
            const cardInnerMatch = cardInnerText.match(/(\d+)/);
            if (cardInnerMatch) {
                const cardInnerNumber = parseInt(cardInnerMatch[1]);
                console.log("Extracted Number (from card-inner):", cardInnerNumber);
                return { totalRecords, cardInnerNumber };
            }
        }
        return { totalRecords: null, cardInnerNumber: null };

    }
}
 
module.exports = {DashboardPage};