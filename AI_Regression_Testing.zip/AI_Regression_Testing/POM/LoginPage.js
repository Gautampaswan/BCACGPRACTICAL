// LoginPage.js
class LoginPage {
    constructor(page) {
        this.page = page;
        this.emailInput = page.getByLabel('Email Id*');
        this.signInButton = page.getByRole('button', { name: 'Sign In' });
    }
 
    async navigate(url) {
        await this.page.goto(url);
        await this.page.waitForLoadState('domcontentloaded');
    }
 
    async login(email) {
        await this.emailInput.fill(email);
        await this.signInButton.click();
        await this.page.waitForTimeout(3000);
        await this.page.waitForLoadState('domcontentloaded');
    }
    async goto() {

        await this.page.waitForTimeout(3000);
        await this.page.goto('https://aismartpprd.airindia.com');
    }
  
}
 
module.exports = {LoginPage};