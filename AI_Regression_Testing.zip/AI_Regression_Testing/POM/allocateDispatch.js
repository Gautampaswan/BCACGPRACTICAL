//const { expect } = require("@playwright/test");

// DashboardPage.js
class allocateDispatch {
    
    constructor(page) {
        
        this.page = page;

        //click dispatch module tab
        this.dispatchModule = page.locator("//a[text()= 'Dispatch Module']");
        //click on Allocate dispatcher tab
        this.allocateDispatcher = page.locator("//button[text()= 'Allocate Dispatchers']");
    
        //Click on the Date Filter Dropdwon
        this.flightFilterIcon = page.locator("img[alt='Not Found']").nth(3);

        this.todayFilter = page.locator("//a[text()='Today']");

        this.tomorrowFilter = page.locator("//a[text()='Tomorrow']");

        this.yesterdayFilter = page.locator("//a[text()='Yesterday']");

        this.last7DaysFilter = page.locator("//a[text()='Last 7 days']");

        this.last14DaysFilter = page.locator("//a[text()='Last 14 days']");


          //Locator for any Station
          //click Airport dropdown at top righthand side of the page
          this.dropdownicon = page.locator(".dpArrows img");
          
          //uncheck all Airport checkbox
          this.uncheckAllairport = page.getByLabel('All Airports');
          
          //locator for one station
          this.checkAnystation = page.getByLabel('BLR');
          //checkAnystation.click();

          //***** Define Locators for More than one Station***********//

          //Define locator for morethan one station
          this.selectBBIstation = page.locator("#BBI");
          //this.checkSecondStation = page.getByLabel('GAU');
          this.selectBOMstation = page.locator("#BOM");

          //Define locator for Flight searchbox****** we can use this locator for to search tail number as well
          this.searchflightbox = page.locator("input[name='Search_Flight']");
 
   
  

       this.paginationLocator = page.locator("div[class='pagePagination d-flex justify-content-between mt-5 ps-2 align-items-center'] div p");
        this.cardInnerLocator = page.locator('.card-inner').nth(0);
        // this.dispatchtabTop = page.locator("//a[text()= 'Dispatch Module']");

      

    }
 
    async openDashboard() {
        await this.page.waitForLoadState('domcontentloaded');
        console.log("Dispatch Module Dashboard has been opened");
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickdispatchModule(){
    await this.page.waitForTimeout(5000);   
    await this.dispatchModule.click();
    }

    
    async clickAllocateDispatcherTab(){

        await this.page.waitForTimeout(5000); 
        await this.allocateDispatcher.click();
    }
 
    async selectFilterforToday() {

        await this.page.waitForTimeout(5000);
        // await this.allocateDispatcher.click();

        await this.flightFilterIcon.click();
        await this.todayFilter.click();
        await this.page.waitForTimeout(5000);
        return await this.validateFlightCount();
    }

    async selectFilterforTomorrow() {//selectFilterTomorrow

        // await this.allocateDispatcher.click();
        await this.flightFilterIcon.click();
        await this.tomorrowFilter.click();
        await this.page.waitForTimeout(5000);
        return await this.validateFlightCount();
        

    }
    async selectFilterforYesterday() {

        await this.allocateDispatcher.click();
        await this.flightFilterIcon.click();
        await this.yesterdayFilter.click();
        await this.page.waitForTimeout(5000);
        return await this.validateFlightCount();
    }

    async selectFilterforLast7Days() {

        await this.allocateDispatcher.click();
        await this.flightFilterIcon.click();      
        await this.last7DaysFilter.click();
        await this.page.waitForTimeout(5000);
        return await this.validateFlightCount();

    }

    async selectFilterforLast14Days() {

        await this.allocateDispatcher.click();
        await this.flightFilterIcon.click();
        await this.last14DaysFilter.click();
        await this.page.waitForTimeout(5000);
        return await this.validateFlightCount();

    }

    //******* Count result for Any Station in All flight tab********//
    async selectCheckboxForOneStation(){

        await this.allocateDispatcher.click();
        //click Airport dropdown located at top righthand side of the page
        await this.dropdownicon.click();

        //Uncheck all Airport dropdown
        await this.uncheckAllairport.click();

        //Check the one station
        await this.checkAnystation.click();

        //validate total flights count for Any station
        
        return await this.validateFlightCount();
    }

    //******* Count result for More than one Station flight tab********//
    async filtersmorethanoneStation(){

        //click on allocate dispatcher
        await this.allocateDispatcher.click();

        await this.dropdownicon.click();
        //Uncheck all Airport dropdown
        await this.uncheckAllairport.click();

        await this.selectBBIstation.click();
        await this.selectBOMstation.click();

        //Check second station
        await this.selectBOMstation.click();
        //validate total flights count for more than one station
        await this.page.waitForTimeout(5000);
        return await this.validateFlightCount();
    }

    //******* Count result for All Station in All flight tab********//
    async selectFiltersforselectallStations(){

        await this.allocateDispatcher.click();
        await this.dropdownicon.click();
        await this.page.waitForTimeout(5000);
        return await this.validateFlightCount();
    }

    //******** Search by full flight number in All flight tab**********//
    async searchByfullFlightNumber(){

        await this.allocateDispatcher.click();
        await this.page.waitForTimeout(5000);

        await this.searchflightbox.fill("AI804");
        await this.page.keyboard.press('Enter');

        await this.page.waitForTimeout(5000);

        //await expect(page.getByText('AI804').first()).toContainText('AI804');
        return await this.validateFlightCount();

    }

    async searchbyfullTailNumber(){


        await this.allocateDispatcher.click();
        await this.searchflightbox.fill("VT-EXF");
        await this.page.keyboard.press('Enter');
        await this.page.waitForTimeout(5000);
        //await this.expect(this.page.getByText('VT-EXG').first()).toContainText('VT-EXG');
        return await this.validateFlightCount();
    }

    async searchByPartialtailNumber(){

        await this.allocateDispatcher.click();
        await this.searchflightbox.fill("VT-E");
        await this.page.keyboard.press('Enter');
        await this.page.waitForTimeout(5000);
        //await this.expect(this.page.getByText('VT-EXG').first()).toContainText('VT-EXG');
        return await this.validateFlightCount();
    }




    //For login page
    async goto() {

        await this.page.waitForTimeout(3000);
        await this.page.goto('https://aismartpprd.airindia.com/DispatchModule');
    }
 
    async validateFlightCount() {
        // Extract and compare flight counts
        const paginationText = await this.paginationLocator.textContent();
        console.log("Extracted Pagination Text:", paginationText);
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
        if (paginationMatch) {
            const totalRecords = parseInt(paginationMatch[1]);
            console.log("Total Records (from pagination):", totalRecords);
            const cardInnerText = await this.cardInnerLocator.textContent();
            const cardInnerMatch = cardInnerText.match(/(\d+)/);
            if (cardInnerMatch) {
                const cardInnerNumber = parseInt(cardInnerMatch[1]);
                console.log("Extracted Number (from card-inner):", cardInnerNumber);
                return { totalRecords, cardInnerNumber };
            }
        }
        return { totalRecords: null, cardInnerNumber: null };




       

    }
}
 
module.exports = {allocateDispatch};