const { test, expect } = require('@playwright/test');

const { LoginPage } = require('../POM/LoginPage');

const { userStory101File } = require('../POM/userStory101File');


let webContext;

//Define object for userStory101File
let downloadADCAndFIC;


test.beforeAll(async ({ browser }) => {//editFICandADC

    // session injection

    webContext = await browser.newContext({ storageState: 'dev2IOCC.json' });

    const page = await webContext.newPage();

    // Create an instance of LoginPage and login once

    const loginPage = new LoginPage(page);

    downloadADCAndFIC = new userStory101File(page);


    await loginPage.navigate('https://aismartdev2.airindia.com/'); // Navigate to the login page

    await loginPage.login('app.monitoring@airindia.com'); // Perform login

});


//Verify that user can download the PDF of FIC/ADC numbers

    test('Verify that user can download the PDF of FIC/ADC numbers', async() =>{

        await downloadADCAndFIC.downloadPDFForDateRange();
    });