const { test, expect } = require('@playwright/test');
const { TIMEOUT } = require('dns');
let webContext;
// this code is about to login in linkedin
test.beforeAll(async ({ browser }) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    //session injection
    // webContext = await browser.newContext({ storageState: 'jai.json' });
    webContext = await browser.newContext({ storageState: 'Gautam_iocc.json' });
 
    await page.close();
});

test.only('download ADC and FIC', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");

    await expect(page.getByRole('button', { name: 'Download ADC/FIC' })).toBeVisible();
    const downloadIcon = await page.locator("[class='btn-outline']");
    await downloadIcon.click();

    const calenderIcon = await page.locator("img[alt='Calendar']");
    await calenderIcon.click();
    await page.locator('div').filter({ hasText: /^From Date \*$/ }).getByRole('img').click();

    await page.getByLabel('Choose Tuesday, October 15th,').click();
    await page.locator('div').filter({ hasText: /^To Date \*$/ }).getByRole('img').click();
    await page.getByLabel('Choose Tuesday, October 15th,').click();
    await page.getByLabel('PDF').check();
    const downloadPromise = page.waitForEvent('download');
    await page.getByRole('button', { name: 'Generate' }).click();
    const download = await downloadPromise;

});

test('FirstOfficer', async () => {


    const page = await webContext.newPage();
    // await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');

    //const checkTwostations = await page.getByLabel('AJL').check();
    //const checkAllstations = await page.getByLabel('All Airports').check();
    console.log("Dispatch Module Dashboard has been opened");
  
    //Click on Allocate dispatcher tab
    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();

    const parentContainer = await page.locator('.captain.d-flex.flex-column');

    // Iterate through all sub-containers
    for (let i = 0; i < await parentContainer.count(); i++) {
      const container = await parentContainer.nth(i);
  
      // Find the First Officer name
      const firstOfficerName = await container.getByText('First Officer');
  
      if (firstOfficerName) {
        // Click the "More" button
        const moreButton = await container.locator('#flight-tabpanel-2 > div > div:nth-child(7) > div > div.justify-content-between.col-4.rightSide.px-3 > div > div:nth-child(2) > a');
        await moreButton.click();
  
        // Verify the content
        const content = await moreButton.textContent();
        const expectedContent = [
          'Basic Details',
          'DEL',
          'Designation',
          'FIRST OFFICER',
          'Fleet',
          '787',
          'Contact Details',
          'Phone',
          '918800743776',
          'Email ID',
          'ezan.hussain@airindia.com',
          'Address',
          'PURANI ABKARI BAMBAGHER, RAMNAGAR NAINITAL, , IN',
          'Passport Details',
          'Passport Issue Date',
          '2016-08-15',
          'Passport No.',
          'P3221513',
          'Passport Expiry Date',
          '2026-08-15',
          'Nationality',
          'IN',
          'Qualifications',
          'Category Qualification',
          'IIIB_P2787/II_P2787',
          'Fleet Qualification',
          '787',
          'Critical Airfield Qualification'
        ];
  
        // Check if the content matches the expected content
        const mismatchedItems = content.split('\n').filter(item => !expectedContent.includes(item.trim()));
        if (mismatchedItems.length === 0) {
          console.log('All expected items found');
        } else {
          console.log(`Mismatched items: ${mismatchedItems.join(', ')}`);
        }
  
        // Break the loop after finding the correct First Officer
        break;
      }
    }
      //Check if station counts are equal or not
      await page.waitForTimeout(3000);
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
    // Get the full text from the pagination element
    await page.waitForTimeout(3000);
    const paginationText = await paginationLocator.textContent();
    console.log("Extracted Pagination Text:", paginationText);
  
    // Extract the number between "of" and "records" using regex
    const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
  if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
      await page.pause();
  
  
  });