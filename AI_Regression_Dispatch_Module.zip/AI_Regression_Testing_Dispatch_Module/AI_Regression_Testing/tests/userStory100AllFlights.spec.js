const { test, expect } = require('@playwright/test');

const { LoginPage } = require('../POM/LoginPage');
const { editFICandADC } = require('../POM/editFICandADC');

let webContext;

let editFicAdcobject;

test.beforeAll(async ({ browser }) => {//editFICandADC

    // session injection

    webContext = await browser.newContext({ storageState: 'dev2IOCC.json' });

    const page = await webContext.newPage();

    // Create an instance of LoginPage and login once

    const loginPage = new LoginPage(page);

    editFicAdcobject = new editFICandADC(page);

    await loginPage.navigate('https://aismartdev2.airindia.com/'); // Navigate to the login page

    await loginPage.login('app.monitoring@airindia.com'); // Perform login

});

//Verify that if the user is able to edit FIC  & ADC number in "ALL Flights"
test('Test edit functionality of ADC and FIC number', async() =>{
 
    await editFicAdcobject.editFICADC();

});

test('Test error message functionality when FIC  is empty', async() => {

    await editFicAdcobject.errorMessageForFIC();
});

test('test error message functionality when ADC is empty ', async() =>{

    await editFicAdcobject.errorMessageForADC();
});