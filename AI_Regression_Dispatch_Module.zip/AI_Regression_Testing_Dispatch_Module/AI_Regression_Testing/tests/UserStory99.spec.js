const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../POM/LoginPage');
const { userStory99File } = require('../POM/userStory99File');

let webContext;
let flightsDetailObject;

test.beforeAll(async ({ browser }) => {//editFICandADC

    // session injection

    webContext = await browser.newContext({ storageState: 'dev2IOCC.json' });

    const page = await webContext.newPage();

    // Create an instance of LoginPage and login once

    const loginPage = new LoginPage(page);

    flightsDetailObject = new userStory99File(page);

    await loginPage.navigate('https://aismartdev2.airindia.com/'); // Navigate to the login page

    await loginPage.login('app.monitoring@airindia.com'); // Perform login

});


/*
"Validate that the user is able to see all the below fields for flight details: Tail No. ·Departure Flight No.  ·Flight Status·Departure Station-· Arrival Station· STD·ETD·EZFW ·
Bay No. ·ADC number· FIC number ·Crew details (Captain & First Officer). "

*/
test('Test that  Tail No. ·Departure Flight No.  ·Flight Status·Departure Station-· Arrival Station· STD·ETD·EZFW should be visible to user', async() =>{

    
    await flightsDetailObject.verifyFlightsDetail();
});
