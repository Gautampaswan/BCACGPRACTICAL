const { test, expect } = require('@playwright/test');
const { loginPageForDispatcher } = require('../../dispatchTabJsFile/loginPageForDispatcher');
const { userStory100File } = require('../../dispatchTabJsFile/userStory100File');

let webContext;
let editFicAdcobjectForMyFlights;



test.beforeAll(async ({ browser }) => {

    // session injection

    webContext = await browser.newContext({ storageState: 'dev2Dispatch.json' });

    const page = await webContext.newPage();

    // Create an instance of LoginPage and login once

    const loginPage = new loginPageForDispatcher(page);

    //await loginPage.goto(); // Navigate to the main page

    await loginPage.navigate('https://aismartdev2.airindia.com/'); // Navigate to the login page

    await loginPage.login('app.monitoring@airindia.com'); // Perform login
 
    //initialize stationFilterForDispatcher class
    editFicAdcobjectForMyFlights      = new userStory100File(page);

});


test('Test edit functionality of ADC and FIC number My Flights', async() =>{
 
    await editFicAdcobjectForMyFlights.editFICADC();

});

test('Test error message functionality when FIC  is empty My Flights', async() => {

    await editFicAdcobjectForMyFlights.errorMessageForFIC();
});

test('test error message functionality when ADC is empty For My Flights', async() =>{

    await editFicAdcobjectForMyFlights.errorMessageForADC();
});