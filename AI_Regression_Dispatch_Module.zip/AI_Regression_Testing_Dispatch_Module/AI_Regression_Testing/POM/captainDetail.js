class captainDetail{

    constructor(page){

        this.page = page;

        this.clickDispatchOption = this.page.locator("//a[text()='Dispatch Module']");

        this.moreButtonCaptain = this.page.locator(".MuiBox-root .border-wrapper a[data-bs-target='#captainDetail']").nth(0);

        this.roosterOption = this.page.locator("//a[text() = 'Roster']");
        // this.paginationLocator = this.page.locator("[class='p-0 mb-0']");     
       //await expect(page.getByRole('tab', { name: 'Crew Details' })).toBeVisible();
    }


    async crewDetailsForCaptain(){
     
        await this.page.waitForLoadState('domcontentloaded'); 
        await this.page.waitForTimeout(15000);  
    
        await this.clickDispatchOption.click();
    
        await this.page.waitForTimeout(15000); 
        await this.page.waitForLoadState('domcontentloaded');
        await this.page.waitForTimeout(15000);
    
        await this.moreButtonCaptain.click();
        return await this.ValidateCrewDetails(); 
    
    }



    async roosterDetailForCaptain(){

        // await this.clickDispatchOption.click();
        await this.roosterOption.click();
        return await this.validateRoosterDetail(); 
    
    }

    async ValidateCrewDetails(){

        const paginationLocator = this.page.locator("[class='p-0 mb-0']");
        const count = await paginationLocator.count();
        if (count === 0) {
        console.error("No pagination elements found");
    } else {
    // Extract text from each pagination element and clean it up
    const paginationElements = await paginationLocator.elementHandles();
    const paginationText = await Promise.all(paginationElements.map(element => element.textContent()));
    console.log("Extracted pagination text:", paginationText);
 
    // Flatten and trim each row text to ensure it's ready for validation
    const flatPaginationText = paginationText.map(text => text.trim());
 
    // Define a map of sections and keywords you expect each row to contain
    const expectedSections = [
        { section: 'Basic Details', keywords: ['DEL', 'Designation', 'Fleet'] },
        { section: 'Contact Details', keywords: ['Phone', 'Email ID', 'Address'] },
        { section: 'Passport Details', keywords: ['Passport Issue Date', 'Passport No.', 'Nationality'] },
        { section: 'Qualifications', keywords: ['Category Qualification', 'Fleet Qualification'] }
    ];
 
    // Variable to track if all rows match
    let allRowsMatch = true;
 
    // Iterate over each expected section and verify it against the extracted pagination text
    expectedSections.forEach((expectedSection, index) => {
        const matchingRow = flatPaginationText.find(rowText =>
            rowText.includes(expectedSection.section) &&
            expectedSection.keywords.every(keyword => rowText.includes(keyword)));
 
        if (matchingRow) {
            console.log(`Row for section "${expectedSection.section}" validated successfully.`);
        } else {
            console.log(`Row for section "${expectedSection.section}" is missing or incomplete.`);
            allRowsMatch = false;
        }
    });
 
    // Final validation summary
    if (allRowsMatch) {
        console.log("All sections matched expected content. Validation passed.");
    } else {
        console.log("Some sections did not match expected content. Validation failed.");
    }
}
    }


//************** Validate Rooster detail***********************//

    async validateRoosterDetail(){

        //return await this.validateRoosterDetail();
    const roasterLocator = this.page.locator("[class = 'modal-body p-0']").first();


    // Extract the text content from roaster.nth(1)
    const roasterText = await roasterLocator.textContent();
    console.log("rooster details:",roasterText);

    if (roasterText) {
    // Trim the extracted text for easier validation
    const trimmedRoasterText = roasterText.trim();
    // Define the required keywords to validate against
    const requiredKeywords = ['Date', 'Tail No.', 'Flight No.', 'From', 'To', 'ETD/ATD', 'ETA/ATA'];

    // Check if all required keywords are present in the extracted text
    const allKeywordsPresent = requiredKeywords.every(keyword => trimmedRoasterText.includes(keyword));

    if (allKeywordsPresent) {
    console.log("All required keywords found in roaster.nth(1). Validation passed.");
    } else {
    console.log("Some required keywords are missing in roaster.nth(1). Validation failed.");
    // Identify and log missing keywords
    const missingKeywords = requiredKeywords.filter(keyword => !trimmedRoasterText.includes(keyword));
    console.log(`Missing keywords: ${missingKeywords.join(', ')}`);
    }
}   else {
    console.error("Failed to retrieve text content from roaster.nth(1)");
}

    }


}

module.exports = { captainDetail };
