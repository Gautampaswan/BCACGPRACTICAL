class userStory99File {
    constructor(page) {
        this.page = page;
        this.clickDispatchOption = this.page.locator("//a[text()='Dispatch Module']");
        this.flightDetailLocator = this.page.locator("[class='align-items-center justify-content-between py-3 row']");
        this.expectedKeywords = [
            'VT-',
            'AI',
            'Yet to Depart',
            'STD',
            'ETD',
            'EZFW',
            'ADC number',
            'FIC number',
            'Captain',
            'First Officer',
            'More Details',//MEL details
            '0 Active MELs'
        ];
    }
 /*
"Validate that the user is able to see all the below fields for flight details: Tail No. ·Departure Flight No.  ·Flight Status·Departure Station-· Arrival Station· STD·ETD·EZFW ·
Bay No. ·ADC number· FIC number ·Crew details (Captain & First Officer). "

*/
    async verifyFlightsDetail(times = 20) {
        await this.clickDispatchOption.click();
 
        for (let i = 0; i < times; i++) {
            console.log(`Iteration ${i + 1}`);
 
            // Get the text content of the nth row
            const flightDetailsText = await this.flightDetailLocator.nth(i).textContent();
            if (!flightDetailsText) {
                console.error(`Iteration ${i + 1}: No text found in row ${i}`);
                continue;
            }
 
            // Trim and log the text for debugging
            const cleanedText = flightDetailsText.trim();
            console.log(`Extracted Text for Row ${i + 1}: ${cleanedText}`);
 
            // Validate each expected keyword in the extracted text
            let allKeywordsPresent = true;
            for (const keyword of this.expectedKeywords) {
                if (!cleanedText.includes(keyword)) {
                    console.error(`Iteration ${i + 1}: Missing or empty value for "${keyword}"`);
                    allKeywordsPresent = false;
                }
            }
 
            // Final validation message for each iteration
            if (allKeywordsPresent) {
                console.log(`Iteration ${i + 1}: All expected keywords are present - PASS`);
            } else {
                console.log(`Iteration ${i + 1}: Some keywords are missing or have empty values - FAIL`);
            }
        }
    }
}
 
module.exports = { userStory99File };