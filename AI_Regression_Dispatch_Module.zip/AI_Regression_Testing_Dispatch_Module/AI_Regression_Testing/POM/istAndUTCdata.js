class istAndUTCdata {
    constructor(page) {
        this.page = page;
        this.clickDispatchOption = this.page.locator("//a[text()='Dispatch Module']");
        this.flightDetailLocator = this.page.locator("[class='align-items-center justify-content-between py-3 row']");
        this.timeZoneToggle = this.page.locator("[name='timeZone']").nth(1);
        this.expectedKeywords = [
            'VT-',
            'AI',
            'Yet to Depart',
            'STD',
            'ETD',
            'EZFW',
            'ADC number',
            'FIC number',
            'Captain',
            'First Officer',
            'More Details', // MEL details
            '0 Active MELs'
        ];
    }
 
    async verifyFlightsDetail(times = 5) {
        await this.clickDispatchOption.click();
        // Map to store initial STD and ETD times with tail numbers as keys
        const initialTimes = new Map();
 
        // First 5 iterations to store initial STD and ETD times with tail numbers
        for (let i = 0; i < times; i++) {
            console.log(`Initial Iteration ${i + 1}`);
 
            // Get the text content of the nth row
            const flightDetailsText = await this.flightDetailLocator.nth(i).textContent();
            if (!flightDetailsText) {
                console.error(`Iteration ${i + 1}: No text found in row ${i}`);
                continue;
            }
 
            const cleanedText = flightDetailsText.trim();
            console.log(`Extracted Text for Row ${i + 1}: ${cleanedText}`);
 
            // Extract STD, ETD, and tail number
            const stdMatch = cleanedText.match(/STD\s*:\s*(\d{2}:\d{2})/);
            const etdMatch = cleanedText.match(/ETD\s*:\s*(\d{2}:\d{2})/);
            const tailNumberMatch = cleanedText.match(/VT-\w+/);
 
            if (stdMatch && etdMatch && tailNumberMatch) {
                const tailNumber = tailNumberMatch[0];
                const stdTime = stdMatch[1];
                const etdTime = etdMatch[1];
                initialTimes.set(tailNumber, { stdTime, etdTime });
                console.log(`Stored for ${tailNumber}: STD = ${stdTime}, ETD = ${etdTime}`);
            } else {
                console.error(`Iteration ${i + 1}: Missing STD, ETD, or Tail Number`);
            }
        }
 
        // Click on the timezone toggle and wait for page reload
        await this.timeZoneToggle.click();
        await this.page.waitForLoadState('domcontentloaded');
 
        // Second 5 iterations to compare updated STD and ETD times
        for (let i = 0; i < times; i++) {
            console.log(`Second Iteration ${i + 1}`);
 
            const flightDetailsText = await this.flightDetailLocator.nth(i).textContent();
            if (!flightDetailsText) {
                console.error(`Iteration ${i + 1}: No text found in row ${i}`);
                continue;
            }
 
            const cleanedText = flightDetailsText.trim();
            console.log(`Extracted Text for Row ${i + 1}: ${cleanedText}`);
 
            // Extract updated STD, ETD, and tail number
            const stdMatch = cleanedText.match(/STD\s*:\s*(\d{2}:\d{2})/);
            const etdMatch = cleanedText.match(/ETD\s*:\s*(\d{2}:\d{2})/);
            const tailNumberMatch = cleanedText.match(/VT-\w+/);
 
            if (stdMatch && etdMatch && tailNumberMatch) {
                const tailNumber = tailNumberMatch[0];
                const updatedSTDTime = stdMatch[1];
                const updatedETDTime = etdMatch[1];
 
                // Check if initial STD and ETD times exist for this tail number
                if (initialTimes.has(tailNumber)) {
                    const { stdTime: initialSTDTime, etdTime: initialETDTime } = initialTimes.get(tailNumber);
 
                    // Convert to Date objects and calculate expected time difference
                    const initialSTDDate = this.convertToDate(initialSTDTime);
                    const initialETDDate = this.convertToDate(initialETDTime);
                    const updatedSTDDate = this.convertToDate(updatedSTDTime);
                    const updatedETDDate = this.convertToDate(updatedETDTime);
 
                    const expectedDifference = 5 * 60 + 30; // 5 hours 30 min in minutes
 
                    // Check time differences for STD and ETD
                    const stdDiff = (initialSTDDate - updatedSTDDate) / (1000 * 60);
                    const etdDiff = (initialETDDate - updatedETDDate) / (1000 * 60);
 
                    if (stdDiff === expectedDifference && etdDiff === expectedDifference) {
                        console.log(`Tail Number ${tailNumber}: STD and ETD times are adjusted by 5 hrs 30 min - PASS`);
                    } else {
                        console.error(`Tail Number ${tailNumber}: STD or ETD times are not adjusted correctly - FAIL`);
                    }
                } else {
                    console.warn(`Tail Number ${tailNumber} not found in initial records.`);
                }
            } else {
                console.error(`Iteration ${i + 1}: Missing updated STD, ETD, or Tail Number`);
            }
        }
    }
 
    convertToDate(timeString) {
        const [hours, minutes] = timeString.split(':').map(Number);
        const date = new Date();
        date.setHours(hours, minutes, 0, 0);
        return date;
    }
}
 
module.exports = { istAndUTCdata };