class firstOfficerDetail{

    constructor(page){

        this.page = page;

        this.clickDispatchOption = this.page.locator("//a[text()='Dispatch Module']");

       //Locate the parent container with multiple sub-containers
        // this.moreButtonFirstOff = this.page.locator('.MuiBox-root .border-wrapper a[data-bs-target="#OfficerDetails"]').nth(2);


        this.moreButtonCaptain = this.page.locator(".MuiBox-root .border-wrapper a[data-bs-target='#captainDetail']").nth(0);

        this.roosterOption = this.page.locator("//a[text() = 'Roster']");

        this.crossButton = this.page.locator("[class='btn-close']").nth(2);

       

        // this.paginationLocator = this.page.locator("[class='p-0 mb-0']");     
       //await expect(page.getByRole('tab', { name: 'Crew Details' })).toBeVisible();
    }

    async clickFirstOffMoreButton() {

        await this.page.waitForLoadState('domcontentloaded'); 
        await this.page.waitForTimeout(20000);

        await this.clickDispatchOption.click();
        // Loop through nth values 0 to 9
        for (let i = 0; i < 10; i++) {
            console.log(`Clicking and validating nth(${i}) more button for First Officer`);
            const moreButtonFirstOff = this.page.locator('.MuiBox-root .border-wrapper a[data-bs-target="#OfficerDetails"]').nth(i);
            await moreButtonFirstOff.click();

            await this.ValidateCrewDetails();
            
            await this.page.waitForTimeout(2000);
            await this.crossButton.click();
            //await this.ValidateCrewDetails();
            //Click the cross button after each iteration  
        }
    }

    /*async clickFirstOffMoreButton(){


        await this.page.waitForLoadState('domcontentloaded'); 
        await this.page.waitForTimeout(15000);  

        await this.clickDispatchOption.click();

        await this.page.waitForTimeout(15000); 
        await this.page.waitForLoadState('domcontentloaded');
        await this.page.waitForTimeout(15000);

        await this.moreButtonFirstOff.click();
        return await this.ValidateCrewDetails(); 

}*/


//*************Rooster Detail for First Officer***********************

/*async clickFirstOffmoreButtonAndClickRoosterDetail(){

    //await this.clickDispatchOption.click();
    //await this.moreButtonFirstOff.click();
    //return await this.ValidateCrewDetails(); 
    //For Rooster Detail
    await this.roosterOption.click();
    return await this.validateRoosterDetail();
}*/
//******************************************************************************************//        

   /* async crewDetailsForCaptain(){
     
    await this.page.waitForLoadState('domcontentloaded'); 
    await this.page.waitForTimeout(15000);  

    await this.clickDispatchOption.click();

    await this.page.waitForTimeout(15000); 
    await this.page.waitForLoadState('domcontentloaded');
    await this.page.waitForTimeout(15000);

    await this.moreButtonCaptain.click();
    return await this.ValidateCrewDetails(); 

}*/

//********************************************************************************************//

//**************************Rooster Detail fir Captain****************************************//

/*async roosterDetailForCaptain(){

    // await this.page.waitForLoadState('domcontentloaded');
    // await this.page.waitForTimeout(15000);
    // await this.clickDispatchOption.click();
    // await this.page.waitForLoadState('domcontentloaded');
    // await this.page.waitForTimeout(15000);

    // await this.moreButtonCaptain.click();
    await this.roosterOption.click();
    return await this.validateRoosterDetail(); 

}*/
//********************************************************************************************//

    async ValidateCrewDetails(){

        const paginationLocator = this.page.locator("[class='p-0 mb-0']");
        const count = await paginationLocator.count();
        if (count === 0) {
        console.error("No pagination elements found");
    } else {
    // Extract text from each pagination element and clean it up
    const paginationElements = await paginationLocator.elementHandles();
    const paginationText = await Promise.all(paginationElements.map(element => element.textContent()));
    console.log("Extracted pagination text:", paginationText);
 
    // Flatten and trim each row text to ensure it's ready for validation
    const flatPaginationText = paginationText.map(text => text.trim());
 
    // Define a map of sections and keywords you expect each row to contain
    const expectedSections = [
        { section: 'Basic Details', keywords: ['DEL', 'Designation', 'Fleet'] },
        { section: 'Contact Details', keywords: ['Phone', 'Email ID', 'Address'] },
        { section: 'Passport Details', keywords: ['Passport Issue Date', 'Passport No.', 'Nationality'] },
        { section: 'Qualifications', keywords: ['Category Qualification', 'Fleet Qualification'] }
    ];
 
    // Variable to track if all rows match
    let allRowsMatch = true;
 
    // Iterate over each expected section and verify it against the extracted pagination text
    expectedSections.forEach((expectedSection, index) => {
        const matchingRow = flatPaginationText.find(rowText =>
            rowText.includes(expectedSection.section) &&
            expectedSection.keywords.every(keyword => rowText.includes(keyword)));
 
        if (matchingRow) {
            console.log(`Row for section "${expectedSection.section}" validated successfully.`);
        } else {
            console.log(`Row for section "${expectedSection.section}" is missing or incomplete.`);
            allRowsMatch = false;
        }
    });
 
    // Final validation summary
    if (allRowsMatch) {
        console.log("All sections matched expected content. Validation passed.");
    } else {
        console.log("Some sections did not match expected content. Validation failed.");
    }
}
    }


//************** Validate Rooster detail***********************//

    async validateRoosterDetail(){

        //return await this.validateRoosterDetail();
    const roasterLocator = this.page.locator("[class = 'modal-body p-0']").first();


    // Extract the text content from roaster.nth(1)
    const roasterText = await roasterLocator.textContent();
    console.log("rooster details:",roasterText);

    if (roasterText) {
    // Trim the extracted text for easier validation
    const trimmedRoasterText = roasterText.trim();
    // Define the required keywords to validate against
    const requiredKeywords = ['Date', 'Tail No.', 'Flight No.', 'From', 'To', 'ETD/ATD', 'ETA/ATA'];

    // Check if all required keywords are present in the extracted text
    const allKeywordsPresent = requiredKeywords.every(keyword => trimmedRoasterText.includes(keyword));

    if (allKeywordsPresent) {
    console.log("All required keywords found in roaster.nth(1). Validation passed.");
    } else {
    console.log("Some required keywords are missing in roaster.nth(1). Validation failed.");
    // Identify and log missing keywords
    const missingKeywords = requiredKeywords.filter(keyword => !trimmedRoasterText.includes(keyword));
    console.log(`Missing keywords: ${missingKeywords.join(', ')}`);
    }
}   else {
    console.error("Failed to retrieve text content from roaster.nth(1)");
}

    }
  


}
module.exports = { firstOfficerDetail };




/*   const paginationLocator = this.page.locator("[class='p-0 mb-0']"); // Replace with your actual selector

        const count = await paginationLocator.count();
        if (count === 0) {
      
        const paginationElements = await paginationLocator.elementHandles(); // Get all element handles
        const paginationText = await Promise.all(paginationElements.map(element => element.textContent()));
        console.log(paginationText);
        console.error("No pagination elements found");
    } else {
        // Get text content from all pagination elements
        const paginationElements = await paginationLocator.elementHandles();
        const paginationText = await Promise.all(paginationElements.map(element => element.textContent()));
    
        // Flatten the paginationText array and trim whitespace
        const flatPaginationText = paginationText.map(text => text.trim());
    
        // Define the expected content
        const expectedContent = [
            'Basic Details',
            'DEL',
            'Designation',
            'FIRST OFFICER',
            'Fleet',
            '787',
            'Contact Details',
            'Phone',
            '918800743776',
            'Email ID',
            'ezan.hussain@airindia.com',
            'Address',
            'PURANI ABKARI BAMBAGHER, RAMNAGAR NAINITAL, , IN',
            'Passport Details',
            'Passport Issue Date',
            '2016-08-15',
            'Passport No.',
            'P3221513',
            'Passport Expiry Date',
            '2026-08-15',
            'Nationality',
            'IN',
            'Qualifications',
            'Category Qualification',
            'IIIB_P2787/II_P2787',
            'Fleet Qualification',
            '787',
            'Critical Airfield Qualification'
        ];
    
        // Check for mismatches
        const mismatchedItems = flatPaginationText.filter(item => !expectedContent.includes(item));
        
        if (mismatchedItems.length === 0) {
            console.log('All expected items found');
        } else {
            console.log(`Mismatched items: ${mismatchedItems.join(', ')}`);
        }
    } */








   