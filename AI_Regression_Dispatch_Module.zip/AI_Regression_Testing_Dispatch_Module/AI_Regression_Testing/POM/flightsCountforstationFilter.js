class flightsCountforstationFilter {
    constructor(page) {
        this.page = page;

        this.dropdownIcon      =   this.page.locator(".dpArrows img");

        this.uncheckAllAirport =   this.page.getByLabel('All Airports');
        
        this.checkAnystation   =   this.page.getByLabel('BLR');

        this.checkGAUStation   =   this.page.getByLabel('GAU')//check();
        this.checkBOMStation   =   this.page.getByLabel('BOM')//check();
        this.checkBBIStation   =   this.page.getByLabel('BBI');
       
       

        //this.clickDispatch = this.page.locator("//a[text()='Dispatch Module']");
    }
 
    // Method to open the Dispatch Module by clicking the link
    // async openDispatchModule() {
    //     await this.clickDispatch.click();
    //     await this.page.waitForLoadState('domcontentloaded');
    //     console.log("Clicked on 'Dispatch Module' link");
    // }
 
    // Method to apply filters based on station labels
    async clickonOneStation() {
        console.log("Dispatch Module Dashboard has been opened");
 
            //await this.page.waitForTimeout(3000);
            //const uncheckAllAirport = await this.page.getByLabel('All Airports');
            await this.page.reload(); 
            await this.page.waitForTimeout(8000); 
            await this.dropdownIcon.click();
            await this.uncheckAllAirport.click();
            await this.checkAnystation.click();
            await this.page.waitForTimeout(8000);
            //return await this.validateFlightCount();
      
    }

    async morethanOneStation(){

            //await this.page.waitForTimeout(5000);
            await this.checkAnystation.click();
       
            //Click on GAU station.
            await this.checkGAUStation.click();
            
            //Click on BOM station.
            await this.checkBOMStation.click();

            //Click on BBI station.
            await this.checkBBIStation.click();
            await this.page.waitForTimeout(10000);
               
    }

    async allStations(){

        await this.uncheckAllAirport.click();  
        await this.page.waitForTimeout(10000); 
        await this.dropdownIcon.click();
    }


 
    // Method to verify flight count
    async validateFlightCount() {
        await this.page.waitForTimeout(3000);
        const paginationLocator = this.page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
 
        // Get the full text from the pagination element
        const paginationText = await paginationLocator.textContent();
        console.log("Extracted Pagination Text:", paginationText);
 
        // Extract the number between "of" and "records" using regex
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
        let totalRecords;
        if (paginationMatch) {
            totalRecords = parseInt(paginationMatch[1]);
            console.log("Total Records (from pagination):", totalRecords);
        }
 
        // Locate the element with class 'card-inner' and extract its number
        const cardInnerLocator = this.page.locator('.card-inner').nth(0);
        const cardInnerText = await cardInnerLocator.textContent();
        console.log("Extracted Card Inner Text:", cardInnerText);
 
        // Extract the number from the 'card-inner'
        const cardInnerMatch = cardInnerText.match(/(\d+)/);
        let cardInnerNumber;
        if (cardInnerMatch) {
            cardInnerNumber = parseInt(cardInnerMatch[1]);
            console.log("Extracted Number (from card-inner):", cardInnerNumber);
        }
 
        // Return both values for validation
        return { totalRecords, cardInnerNumber };
    }
}
    
 
module.exports = { flightsCountforstationFilter };