// LoginPage.js
class LoginPage {
    constructor(page) {
        this.page = page;
        this.emailInput = page.getByLabel('Email Id*');
        this.signInButton = page.getByRole('button', { name: 'Sign In' });
    }
 
    async navigate(url) {
        await this.page.waitForLoadState('domcontentloaded');
        await this.page.goto(url);
       
    }
 
    async login(email) {

        await this.page.waitForLoadState('domcontentloaded');
        await this.emailInput.fill(email);
        //await this.page.waitForLoadState('networkidle');
        await this.page.waitForLoadState('domcontentloaded');
        await this.signInButton.click();
        await this.page.waitForTimeout(10000);
        
    }
    // async goto() {

    //     await this.page.waitForTimeout(5000);
    //     await this.page.goto('https://aismartdev2.airindia.com');//https://aismartpprd.airindia.com

    //     //https://aismartdev2.airindia.com/
    // }
  
}
 
module.exports = {LoginPage};