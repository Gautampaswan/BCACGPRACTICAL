class userStory101File {
    constructor(page) {
        this.page = page;
 
        // Main locators
        this.clickDispatchOption = this.page.locator("//a[text()='Dispatch Module']");
        this.downloadFICAndADC = this.page.locator("[class='btn-outline']");
        this.clickPDF = this.page.locator("[name='name-format']").nth(0);
        this.clickGenerate = this.page.locator("[class='btn-primary']");
 
        // Calendar icon locators for From and To dates
        this.fromCalendarIcon = this.page.locator("img[alt='Calendar']").nth(0);
        this.toCalendarIcon = this.page.locator("img[alt='Calendar']").nth(1);
 
        // Week locators for From and To dates
        this.fromWeekContainer = this.page.locator("[class='react-datepicker__week']").nth(1);
        this.toWeekContainer = this.page.locator("[class='react-datepicker__week']").nth(0);
    }
 
    async downloadPDFForDateRange() {
        await this.page.waitForLoadState('domcontentloaded');

        await this.clickDispatchOption.click();
        await this.downloadFICAndADC.click();
        // Open From date calendar
        await this.fromCalendarIcon.click();
 
        // Extract dates for the From week
        const fromDates = await this.fromWeekContainer.locator("[role='option']").all();
 
        for (let i = 0; i < fromDates.length; i++) {
            const fromDate = fromDates[i];
            await fromDate.click(); // Select "From" date
 
            // Open To date calendar
            await this.toCalendarIcon.click();
 
            // Extract dates for the To week
            const toDates = await this.toWeekContainer.locator("[role='option']").all();
 
            for (let j = i; j < toDates.length; j++) { // Ensure 'To' date is after or same as 'From'
                const toDate = toDates[j];
                await toDate.click(); // Select "To" date
 
                // Click on the PDF option
                await this.clickPDF.click();
 
                // Wait for the Generate button to become clickable
                await this.clickGenerate.waitFor({ state: 'attached' });
                await this.clickGenerate.click(); // Click to generate the PDF
 
                // Log the selected date range
                console.log(`Downloaded PDF for range: From - ${await fromDate.getAttribute("aria-label")}, To - ${await toDate.getAttribute("aria-label")}`);
            }
        }
    }
}
 
module.exports = { userStory101File };