class stationFilterForDispatcher{

   
        constructor(page) {
            this.page = page;
    
            this.dropdownIcon      =   this.page.locator(".dpArrows img");
    
            this.uncheckAllAirport =   this.page.getByLabel('All Airports');
            
            this.checkAnystation   =   this.page.getByLabel('BLR');
    
            this.checkGAUStation   =   this.page.getByLabel('GAU')//check();
            this.checkBOMStation   =   this.page.getByLabel('BOM')//check();
            this.checkBBIStation   =   this.page.getByLabel('BBI');

            this.allocateDispatcherButtonForStation = page.locator("//button[text()= 'Allocate Dispatchers']");

            this.paginationLocator = page.locator("div[class='pagePagination d-flex justify-content-between mt-5 ps-2 align-items-center'] div p");
            this.cardInnerLocator = page.locator('.card-inner').nth(0);
        }
     

// Method to apply filters based on station labels
async selectCheckboxForOneStation() {
      
    //Reload the page
    await this.page.reload(); 
    //Click on Allocate Dispatcher Tab
    await this.allocateDispatcherButtonForStation.click();
    await this.page.waitForTimeout(10000); 

    //Click on All Airports Dropdown
    await this.dropdownIcon.click();

    //Check the All Airports Checkbox
    await this.uncheckAllAirport.click();

    //Select any one Station
    await this.checkAnystation.click();
    await this.page.waitForTimeout(10000);
    //return await this.validateFlightCount();          
            
          
}
    
async filtersmorethanoneStation() {
    
     //Click on BOM station.
     await this.checkBOMStation.click();

     //Click on BBI station.
     await this.checkBBIStation.click();
     
    //Click on GAU station.
    await this.checkGAUStation.click();
    await this.page.waitForTimeout(10000);          
                 
               
    }

    
async selectFiltersforallStations(){
    
    await this.uncheckAllAirport.click();  
    await this.page.waitForTimeout(10000);
    await this.dropdownIcon.click();
      
}
     
// **************** Method to verify flight count ************************//

        async validateFlightCount() {
            // Extract and compare flight counts
        const paginationText = await this.paginationLocator.textContent();
        console.log("Extracted Pagination Text:", paginationText);
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
        if (paginationMatch) {
            const totalRecords = parseInt(paginationMatch[1]);
            console.log("Total Records (from pagination):", totalRecords);
            const cardInnerText = await this.cardInnerLocator.textContent();
            const cardInnerMatch = cardInnerText.match(/(\d+)/);
            if (cardInnerMatch) {
                const cardInnerNumber = parseInt(cardInnerMatch[1]);
                console.log("Extracted Number (from card-inner):", cardInnerNumber);
                return { totalRecords, cardInnerNumber };
            }
        }
        return { totalRecords: null, cardInnerNumber: null };
        }
    }
        
     
    module.exports = { stationFilterForDispatcher };
