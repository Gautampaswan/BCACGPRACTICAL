class userStory100File{

    constructor(page){

        this.page = page;
    
        this.clickDispatchOption = this.page.locator("//a[text()='Dispatch Module']");

        //For edit
        this.clickADC            = this.page.locator("[name='ADC']").nth(1);
                                    

        this.clickFIC            = this.page.locator("[name='FIC']").nth(1);
        this.clickTickButton     = this.page.locator("[class='ms-2']").nth(1);
        this.clickCrossButton  =  this.page.locator("[class='btn-close']").nth(4);
        //this.savePopup   =   this.page.locator(" //[class='successADCFIC']");

        // For mandaterory error Message For FIC
        this.clickADCForErrorMessage            = this.page.locator("[name='ADC']").nth(2);
                                    

        this.clickFICForErrorMessage            = this.page.locator("[name='FIC']").nth(2);
        this.clickTickButtonForErrorMessage     = this.page.locator("[class='ms-2']").nth(2);

        //this.savePopup   =   this.page.locator(" //[class='successADCFIC']");
        this.errorMessage = this.page.locator("[class='dispatchFicAdcErrorMessage']").nth(2);


         // **************For mandaterory error Message For ADC******************************//
         this.clickADCForErrorMessageADC            = this.page.locator("[name='ADC']").nth(3);
                                    

         this.clickFICForErrorMessageADC            = this.page.locator("[name='FIC']").nth(3);
         this.clickTickButtonForErrorMessageADC     = this.page.locator("[class='ms-2']").nth(3);
 
         //this.savePopup   =   this.page.locator(" //[class='successADCFIC']");
         this.errorMessage = this.page.locator("[class='dispatchFicAdcErrorMessage']").nth(3);
    }


    async editFICADC(){

        await this.clickDispatchOption.click();
        await this.clickADC.click();
        await this.clickADC.fill("44test440");
        await this.clickFIC.click();
        await this.clickFIC.fill("234343");
        await this.clickTickButton.click();
        await this.clickCrossButton.click();
        //await this.savePopup.click();
       
    }
    async errorMessageForFIC() {
        await this.clickDispatchOption.click();
        await this.clickADCForErrorMessage.click();
        await this.clickADCForErrorMessage.fill("44test440");  // Fill ADC field
        await this.clickFICForErrorMessage.click();            // Focus on FIC field
        await this.clickFICForErrorMessage.fill('');           // Leave FIC field empty
        await this.clickTickButtonForErrorMessage.click();     // Click TickButton to trigger validation
 
        // Check if the error message appears
        const isErrorVisible = await this.errorMessage.isVisible();
        if (isErrorVisible) {
            const errorMessageText = await this.errorMessage.textContent();
            console.log('Error message:', errorMessageText); // Logs the error message
        } else {
            console.log('Error message did not appear as expected.');
        }
    }

    //****************Required Field message for ADC*********************//

    async errorMessageForADC() {
        await this.clickDispatchOption.click();
        await this.clickADCForErrorMessageADC.click();
        await this.clickADCForErrorMessageADC.fill('');  // Fill ADC field
        await this.clickFICForErrorMessageADC.click();            // Focus on FIC field
        await this.clickFICForErrorMessageADC.fill("23434");           // Leave FIC field empty
        await this.clickTickButtonForErrorMessageADC.click();     // Click TickButton to trigger validation
 
        // Check if the error message appears
        const isErrorVisible = await this.errorMessage.isVisible();
        if (isErrorVisible) {
            const errorMessageText = await this.errorMessage.textContent();
            console.log('Error message:', errorMessageText); // Logs the error message
        } else {
            console.log('Error message did not appear as expected.');
        }
    }

   /* async verifyFlightsDetail(){

        await this.clickDispatchOption.click();
        const rows1 = await this.page.locator("[class='align-items-center justify-content-between py-3 row']").nth(0).textContent();



        console.log(rows1);

    }*/



}

 module.exports = { userStory100File };



