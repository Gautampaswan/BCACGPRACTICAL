//const { expect } = require("@playwright/test");

// DashboardPage.js
class allocateDispatch {
    
    constructor(page) {
        
        this.page = page;

        //click dispatch module tab
        this.dispatchModuleForDispatcherTab = page.locator("//a[text()= 'Dispatch Module']");
        //click on Allocate dispatcher tab
        this.allocateDispatcherButton = page.locator("//button[text()= 'Allocate Dispatchers']");
    
        //Click on the Date Filter Dropdwon
        this.flightFilterIcon = page.locator("img[alt='Not Found']").nth(3);

        this.todayFilter = page.locator("//a[text()='Today']");

        this.tomorrowFilter = page.locator("//a[text()='Tomorrow']");

        this.yesterdayFilter = page.locator("//a[text()='Yesterday']");

        this.last7DaysFilter = page.locator("//a[text()='Last 7 days']");

        this.last14DaysFilter = page.locator("//a[text()='Last 14 days']");


       this.paginationLocator = page.locator("div[class='pagePagination d-flex justify-content-between mt-5 ps-2 align-items-center'] div p");
        this.cardInnerLocator = page.locator('.card-inner').nth(0);
        // this.dispatchtabTop = page.locator("//a[text()= 'Dispatch Module']");

      

    }
 
    async openDashboard() {
        await this.page.waitForLoadState('domcontentloaded');
        console.log("Dispatch Module Dashboard has been opened");
        await this.page.waitForLoadState('domcontentloaded');
    }

    async clickdispatchModuleForDispatcherTab(){
    await this.page.waitForTimeout(5000);   
    await this.dispatchModuleForDispatcherTab.click();
    }

    
    async clickAllocateDispatcherTab(){

        await this.page.waitForTimeout(5000); 
        await this.allocateDispatcherButton.click();
    }
 
    async selectFilterforToday() {
 
        //await this.allocateDispatcherButton.click();
        await this.flightFilterIcon.click();
        await this.todayFilter.click();
        await this.page.waitForTimeout(5000);
        await this.page.waitForLoadState('domcontentloaded');
        //return await this.validateFlightCount();
    }

    async selectFilterforTomorrow() {   

        // await this.allocateDispatcherButton.click();
        await this.flightFilterIcon.click();
        await this.tomorrowFilter.click();
        await this.page.waitForLoadState('domcontentloaded');
        await this.page.waitForTimeout(10000);
        
    }

    async selectFilterforYesterday() {

        // await this.allocateDispatcherButton.click();
        await this.flightFilterIcon.click();
        await this.yesterdayFilter.click();
        await this.page.waitForLoadState('domcontentloaded');
        await this.page.waitForTimeout(10000);
    }


    async selectFilterforLast7Days() {
        
        //await this.allocateDispatcherButton.click();
        await this.flightFilterIcon.click();      
        await this.last7DaysFilter.click();
        await this.page.waitForTimeout(10000);
    }

    async selectFilterforLast14Days() {
       
        //await this.allocateDispatcherButton.click();
        await this.flightFilterIcon.click();
        await this.last14DaysFilter.click();
        await this.page.waitForTimeout(10000);

        const paginationText = await this.paginationLocator.textContent();
        console.log("Extracted Pagination Text:", paginationText);
 
    // Extract the total records count from the pagination text
    const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
    if (paginationMatch) {
        const totalRecords = parseInt(paginationMatch[1]);
        console.log("Total Records (from pagination):", totalRecords);
 
        // Extract the card inner text and number from it
        const cardInnerText = await this.cardInnerLocator.textContent();
        const cardInnerMatch = cardInnerText.match(/(\d+)/);
        if (cardInnerMatch) {
            const cardInnerNumber = parseInt(cardInnerMatch[1]);
            console.log("Extracted Number (from card-inner):", cardInnerNumber);
 
            // Compare extracted numbers and log pass/fail result
            if (totalRecords === cardInnerNumber) {
                console.log("Flight count validation: PASS");
            } else {
                console.error("Flight count validation: FAIL");
            }
            return; // Stop execution if we reached here
        }
    }
 
    console.error("Flight count validation: FAIL - Unable to extract counts");
            


        
       
    }





    //********************Validate flights count************************//
    async validateFlightCount() {
        // Extract and compare flight counts
        const paginationText = await this.paginationLocator.textContent();
        console.log("Extracted Pagination Text:", paginationText);
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
        if (paginationMatch) {
            const totalRecords = parseInt(paginationMatch[1]);
            console.log("Total Records (from pagination):", totalRecords);
            const cardInnerText = await this.cardInnerLocator.textContent();
            const cardInnerMatch = cardInnerText.match(/(\d+)/);
            if (cardInnerMatch) {
                const cardInnerNumber = parseInt(cardInnerMatch[1]);
                console.log("Extracted Number (from card-inner):", cardInnerNumber);
                return { totalRecords, cardInnerNumber };
            }
        }
        return { totalRecords: null, cardInnerNumber: null };

    }
    /////**********END Validation Function*****************/////////






    //******* Count result for Any Station in All flight tab********//
    // async selectCheckboxForOneStation(){

    //     await this.allocateDispatcher.click();
    //     //click Airport dropdown located at top righthand side of the page
    //     await this.dropdownicon.click();

    //     //Uncheck all Airport dropdown
    //     await this.uncheckAllairport.click();

    //     //Check the one station
    //     await this.checkAnystation.click();

    //     //validate total flights count for Any station
        
    //     return await this.validateFlightCount();
    // }

    // //******* Count result for More than one Station flight tab********//
    // async filtersmorethanoneStation(){

    //     //click on allocate dispatcher
    //     await this.allocateDispatcher.click();

    //     await this.dropdownicon.click();
    //     //Uncheck all Airport dropdown
    //     await this.uncheckAllairport.click();

    //     await this.selectBBIstation.click();
    //     await this.selectBOMstation.click();

    //     //Check second station
    //     await this.selectBOMstation.click();
    //     //validate total flights count for more than one station
    //     await this.page.waitForTimeout(5000);
    //     return await this.validateFlightCount();
    // }

    // //******* Count result for All Station in All flight tab********//
    // async selectFiltersforselectallStations(){

    //     await this.allocateDispatcher.click();
    //     await this.dropdownicon.click();
    //     await this.page.waitForTimeout(5000);
    //     return await this.validateFlightCount();
    // }

    //******** Search by full flight number in All flight tab**********//
   /* async searchByfullFlightNumber(){

        await this.allocateDispatcher.click();
        await this.page.waitForTimeout(5000);

        await this.searchflightbox.fill("AI804");
        await this.page.keyboard.press('Enter');

        await this.page.waitForTimeout(5000);

        //await expect(page.getByText('AI804').first()).toContainText('AI804');
        return await this.validateFlightCount();

    }*/

   /* async searchbyfullTailNumber(){


        await this.allocateDispatcher.click();
        await this.searchflightbox.fill("VT-EXF");
        await this.page.keyboard.press('Enter');
        await this.page.waitForTimeout(5000);
        //await this.expect(this.page.getByText('VT-EXG').first()).toContainText('VT-EXG');
        return await this.validateFlightCount();
    }*/

    /*async searchByPartialtailNumber(){

        await this.allocateDispatcher.click();
        await this.searchflightbox.fill("VT-E");
        await this.page.keyboard.press('Enter');
        await this.page.waitForTimeout(5000);
        //await this.expect(this.page.getByText('VT-EXG').first()).toContainText('VT-EXG');
        return await this.validateFlightCount();
    }*/




    //For login page
    // async goto() {

    //     await this.page.waitForTimeout(3000);
    //     await this.page.goto('https://aismartpprd.airindia.com/DispatchModule');
    // }
 
   
}
 
module.exports = {allocateDispatch};