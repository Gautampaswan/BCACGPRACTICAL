class allocateDispSearchBYTF{

    constructor(page){

        this.page = page;

        this.searchflightbox =      this.page.locator("input[name='Search_Flight']");
        //this.dropdownIcon      =   this.page.locator(".dpArrows img");
    
    }
//************ Seacrh by full Flight number *********************//
    async searchByfullFlightNumberForallocateDispatcher(){

        await this.page.waitForTimeout(3000);
        await this.searchflightbox.fill("AI804");
        await this.page.keyboard.press('Enter');
        // await this.dropdownIcon.click();
        await this.page.waitForTimeout(3000);
         
    }

//************ Seacrh by Half Flight number *********************//
    async searchByHalfFlightNumberForallocateDispatcher(){

        await this.searchflightbox.fill("804");
        await this.page.keyboard.press('Enter');
        await this.page.waitForTimeout(10000);
        
         
    }

//************ Seacrh by full tail number *********************//

    async seacrhByfullTailNumberForAllocateDispatcher(){

        await this.searchflightbox.fill("VT-EXG");
        await this.page.keyboard.press('Enter');
        await this.page.waitForTimeout(10000);
 
    }

//*************** Search By Half Tail Number **************//

    async seacrhByHalfTailNumberForAllocateDispatcher(){

        await this.searchflightbox.fill("EXG");
        await this.page.keyboard.press('Enter');
        await this.page.waitForTimeout(10000);
        //return await this.validateFlightCount();   
    }





//******************* Text Validation For *************************//

    async validateFlightCount() {
        await this.page.waitForTimeout(3000);
        const paginationLocator = this.page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
 
        // Get the full text from the pagination element
        const paginationText = await paginationLocator.textContent();
        console.log("Extracted Pagination Text:", paginationText);
 
        // Extract the number between "of" and "records" using regex
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
        let totalRecords;
        if (paginationMatch) {
            totalRecords = parseInt(paginationMatch[1]);
            console.log("Total Records (from pagination):", totalRecords);
        }
 
        // Locate the element with class 'card-inner' and extract its number
        const cardInnerLocator = this.page.locator('.card-inner').nth(0);
        const cardInnerText = await cardInnerLocator.textContent();
        console.log("Extracted Card Inner Text:", cardInnerText);
 
        // Extract the number from the 'card-inner'
        const cardInnerMatch = cardInnerText.match(/(\d+)/);
        let cardInnerNumber;
        if (cardInnerMatch) {
            cardInnerNumber = parseInt(cardInnerMatch[1]);
            console.log("Extracted Number (from card-inner):", cardInnerNumber);
        }
 
        // Return both values for validation
        return { totalRecords, cardInnerNumber };
    }

}
module.exports = { allocateDispSearchBYTF };