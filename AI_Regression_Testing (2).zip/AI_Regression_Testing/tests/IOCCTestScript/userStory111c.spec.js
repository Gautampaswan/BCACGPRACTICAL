const { test, expect } = require('@playwright/test');
const { TIMEOUT } = require('dns');
let webContext;
// this code is about to login in linkedin
test.beforeAll(async ({ browser }) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    //session injection
    // webContext = await browser.newContext({ storageState: 'jai.json' });
    webContext = await browser.newContext({ storageState: 'Gautam_iocc.json' });
 
    await page.close();
});
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

//Verify User will be able to see the search search as per aircrafttype selection
test('Aircraft', async () => {


    const page = await webContext.newPage();
    // await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    //await page.waitforSelector("await page.getByText('Dispatch Module').click();");
    //await page.getByText("Dispatch Module").first().click();
  
    //await page.waitForURL("https://aismartpprd.airindia.com/DispatchModule");
    //await page.waitForURL("https://aismartpprd.airindia.com/DispatchModule");
   
    //const checkTwostations = await page.getByLabel('AJL').check();
    //const checkAllstations = await page.getByLabel('All Airports').check();
    console.log("Dispatch Module Dashboard has been opened");
  
    //Click on Allocate dispatcher tab
    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();

    await page.waitForTimeout(3000);
    await expect(page.getByLabel('Aircraft Type')).toBeVisible();
    await page.locator('.MuiInputAdornment-root > span:nth-child(2) > img').first().click();
    await page.getByRole('option', { name: 'A319' }).click();
    await expect(page.locator('td:nth-child(3)').first()).toBeVisible();
    await expect(page.locator('tr:nth-child(2) > td:nth-child(3)')).toBeVisible();
    await expect(page.locator('tbody')).toContainText('A319');
    await expect(page.locator('tbody')).toContainText('A319');
    
      //Check if station counts are equal or not
      await page.waitForTimeout(3000);
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
    // Get the full text from the pagination element
    await page.waitForTimeout(3000);
    const paginationText = await paginationLocator.textContent();
    console.log("Extracted Pagination Text:", paginationText);
  
    // Extract the number between "of" and "records" using regex
    const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
  if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
  
  
    
    
    await page.pause();
  
  
  });

  //Verify that if the user selects the filter for “Today”, then user should be able to view the search result as per the filter selected in "Dispatcher Allocation".
  test('Today In dispatcher', async () => {

    const page = await webContext.newPage();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    console.log("Dispatch Module Dashboard has been opened");
  
    //Click on Allocate dispatcher tab
    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();
  
    //Click Dropedown and select Today date
    await page.waitForTimeout(3000);
    await page.locator("img[alt='Not Found']").nth(3).click();
    await page.locator("//a[text()= 'Today']").click();

 
    
      //Check if flight count correct or not
      await page.waitForTimeout(3000);

      const paginationLocator =  page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
     // Get the full text from the pagination element
        await page.waitForTimeout(3000);
        const paginationText = await paginationLocator.textContent();
        console.log("Extracted Pagination Text:", paginationText);
  
     // Extract the number between "of" and "records".
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
        if (paginationMatch) {
        const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
        console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner'.
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
              console.log("Could not extract number from 'card-inner'.");
      }
  } else {
              console.log("Could not find the number in the pagination text.");
  }
             await page.pause();
  
  
  });


    //Verify that if the user selects the filter for “Today”, then user should be able to view the search result as per the filter selected in "yesterday".
  test('yesterday In dispatcher', async () => {

    const page = await webContext.newPage();
    // await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    console.log("Dispatch Module Dashboard has been opened");
  
    //Click on Allocate dispatcher tab
    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();
  
    await page.waitForTimeout(3000);
    await page.locator("img[alt='Not Found']").nth(3).click();
    await page.locator("//a[text()= 'Yesterday']").click();

    //Check if station counts are equal or not
    await page.waitForTimeout(3000);
    const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
    // Get the full text from the pagination element
    await page.waitForTimeout(3000);
    const paginationText = await paginationLocator.textContent();
    console.log("Extracted Pagination Text:", paginationText);
  
    // Extract the number between "of" and "records" using regex
    const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
   if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
             console.log("Could not extract number from 'card-inner'.");
      }
  } else {
           console.log("Could not find the number in the pagination text.");
  }
  
          await page.pause();
  
  
  });

     //Verify that if the user selects the filter for “Today”, then user should be able to view the search result as per the filter selected in "Tomorrow".
  test('Tomorrow In dispatcher', async () => {

    const page = await webContext.newPage();
    // await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    console.log("Dispatch Module Dashboard has been opened");
  
    //Click on Allocate dispatcher tab
    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();
  
    await page.waitForTimeout(3000);
    await page.locator("img[alt='Not Found']").nth(3).click();
    await page.locator("//a[text()= 'Tomorrow']").click();

      //Check if station counts are equal or not
      await page.waitForTimeout(3000);
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
  // Get the full text from the pagination element
  await page.waitForTimeout(3000);
  const paginationText = await paginationLocator.textContent();
  console.log("Extracted Pagination Text:", paginationText);
  
  // Extract the number between "of" and "records" using regex
  const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
  if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
            console.log("Could not extract number from 'card-inner'.");
      }
  } else {
            console.log("Could not find the number in the pagination text.");
  }          await page.pause();
   
  });

  //Verify that if the user selects the filter for “Today”, then user should be able to view the search result as per the filter selected in "Last 7 days In dispatcher".
  test('Last 7 days In dispatcher', async () => {

    const page = await webContext.newPage();
    // await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    //await page.waitforSelector("await page.getByText('Dispatch Module').click();");
    //await page.getByText("Dispatch Module").first().click();
  
    //await page.waitForURL("https://aismartpprd.airindia.com/DispatchModule");
    //await page.waitForURL("https://aismartpprd.airindia.com/DispatchModule");
   
    //const checkTwostations = await page.getByLabel('AJL').check();
    //const checkAllstations = await page.getByLabel('All Airports').check();
    console.log("Dispatch Module Dashboard has been opened");
  
    //Click on Allocate dispatcher tab
    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();
  
    await page.waitForTimeout(3000);
    await page.locator("img[alt='Not Found']").nth(3).click();
    await page.locator("//a[text()= 'Last 7 days']").click();

    //Check if station counts are equal or not
    await page.waitForTimeout(3000);
    const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
    // Get the full text from the pagination element
    await page.waitForTimeout(3000);
    const paginationText = await paginationLocator.textContent();
    console.log("Extracted Pagination Text:", paginationText);
  
  // Extract the number between "of" and "records" using regex
  const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
  if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
  
  
    
    
    await page.pause();
  
  
  });

  //Verify that if the user selects the filter for “Today”, then user should be able to view the search result as per the filter selected in "Last 14 days In dispatcher".
  test('Last 14 days In dispatcher', async () => {

    const page = await webContext.newPage();
    // await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    
    //const checkTwostations = await page.getByLabel('AJL').check();
    //const checkAllstations = await page.getByLabel('All Airports').check();
    console.log("Dispatch Module Dashboard has been opened");
  
    //Click on Allocate dispatcher tab
    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();
  
    await page.waitForTimeout(3000);
    await page.locator("img[alt='Not Found']").nth(3).click();
    await page.locator("//a[text()= 'Last 14 days']").click();

      //Check if station counts are equal or not
      await page.waitForTimeout(3000);
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
  // Get the full text from the pagination element
  await page.waitForTimeout(3000);
  const paginationText = await paginationLocator.textContent();
  console.log("Extracted Pagination Text:", paginationText);
  
  // Extract the number between "of" and "records" using regex
  const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
  if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
     await page.pause();
  
  
  });
  //Verify that if the user selects the filter for  stations “Any one station ” stations then user should be able to view the search result as per the filter selected in "Dispatcher Allocation".
test('Any one station', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    console.log("Dispatch Module Dashboard has been opened");
  
    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();
     const dropdownicon = await page.locator(".dpArrows img");
     await dropdownicon.click();
     //Uncheck All Airport option
     //dropdown await page.getByRole('button', { name: 'All Airports' }).click();
     const uncheckAllairport = await page.getByLabel('All Airports')//uncheck();
     await uncheckAllairport.uncheck();
     //Select any Station from dropdown
     const checkAnystation = await page.getByLabel('BLR');
     await checkAnystation.click();
  
   
     //Check if station counts are equal or not
      await page.waitForTimeout(3000);
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
      // Get the full text from the pagination element
       await page.waitForTimeout(3000);
       const paginationText = await paginationLocator.textContent();
        console.log("Extracted Pagination Text:", paginationText);
  
       // Extract the number between "of" and "records" using regex
       const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
      if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
        await page.pause();
  });

  //Verify that if the user selects the filter for  stations “More than one  station ” stations then user should be able to view the search result as per the filter selected in "Dispatcher Allocation".
  test('More than one  station', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    
    console.log("Dispatch Module Dashboard has been opened");

    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();
     const dropdownicon = await page.locator(".dpArrows img");
     await dropdownicon.click();
     //Uncheck All Airport option
     const uncheckAllairport = await page.getByLabel('All Airports')//uncheck();
     await uncheckAllairport.uncheck();
     //Select any Station from dropdown
     const checkAnystation = await page.getByLabel('BLR');
     await checkAnystation.click();
     const checkTwostations = await page.getByLabel('GAU')//check();
     await checkTwostations.click();
    //Check if station counts are equal or not
      await page.waitForTimeout(3000);
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
    // Get the full text from the pagination element
       const paginationText = await paginationLocator.textContent();
       console.log("Extracted Pagination Text:", paginationText);
  
    // Extract the number between "of" and "records" using regex
       const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
       if (paginationMatch) {
       const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
       console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
    await page.pause();
  
  
  });


    //Verify that if the user selects the filter for  stations “All  stations ” stations then user should be able to view the search result as per the filter selected in "Dispatcher Allocation".
     test('Select All Stations', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    console.log("Dispatch Module Dashboard has been opened");
  
    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();
     const dropdownicon = await page.locator(".dpArrows img");
     await dropdownicon.click();
     //Check if station counts are equal or not
      await page.waitForTimeout(3000);
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
    // Get the full text from the pagination element
     const paginationText = await paginationLocator.textContent();
     console.log("Extracted Pagination Text:", paginationText);
  
    // Extract the number between "of" and "records" using regex
     const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
     if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);

      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
    await page.pause();
  
  });

  //Verify that user can Search By full flightNo (Ex AI678) in "Dispatcher Allocation"
  test('Test SearchBy Full flight number', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");

    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();

    //click on search box
    const searchflightbox = await page.locator("input[name='Search_Flight']");
    await searchflightbox.click();

    //Type flight number
     await page.waitForTimeout(3000);
     await searchflightbox.fill("AI446");
     await page.waitForTimeout(3000);
     await page.keyboard.press('Enter');
     await expect(page.getByText('AI446').first()).toContainText('AI446');

      await page.waitForTimeout(3000);
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
     // Get the full text from the pagination element
      const paginationText = await paginationLocator.textContent();
      console.log("Extracted Pagination Text:", paginationText);
  
     // Extract the number between "of" and "records" using regex
     const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
    if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
    } else {
      console.log("Could not find the number in the pagination text.");
    }
    await page.pause();
  
  });


///////////////////////////////////////Search by full tail number///////////////////////////////
//Verify that user can Search By full TailNo (Ex VT-AXN) in "Dispatcher Allocation".

test('Test SearchBy Full tail number', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");

    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();

    //click on search box
    const searchflightbox = await page.locator("input[name='Search_Flight']");
    await searchflightbox.click();

   
     await page.waitForTimeout(3000);
      //Type tail number number
     await searchflightbox.fill("VT-JRB");
     await page.waitForTimeout(3000);
     //Click Enter
     await page.keyboard.press('Enter');

     //Validate tail number
     await expect(page.getByText('VT-JRB').first()).toContainText('VT-JRB');

      await page.waitForTimeout(3000);
      //Validate total flights with pagination number
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
     // Get the full text from the pagination element
      const paginationText = await paginationLocator.textContent();
      console.log("Extracted Pagination Text:", paginationText);
  
     // Extract the number between "of" and "records" using regex
     const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
    if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
    } else {
      console.log("Could not find the number in the pagination text.");
    }
    await page.pause();
  
  });

  //*****************************Search partial tail number*****************
  //Verify that user can Search By partial TailNo (Ex AXN) in "Dispatcher Allocation".
  //**************************Not working********************************************//

  /*test.only('Test SearchBy partial tail number', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();
    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");

    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();

    //click on search box
    const searchflightbox = await page.locator("input[name='Search_Flight']");
    await searchflightbox.click();

   
     await page.waitForTimeout(3000);
      //Type tail number number
     await searchflightbox.fill("VT-JRB");
     await page.waitForTimeout(3000);
     //Click Enter
     await page.keyboard.press('Enter');

     //Validate tail number
     await expect(page.getByText('VT-JRB').first()).toContainText('VT-JRB');

      await page.waitForTimeout(3000);
      //Validate total flights with pagination number
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
     // Get the full text from the pagination element
      const paginationText = await paginationLocator.textContent();
      console.log("Extracted Pagination Text:", paginationText);
  
     // Extract the number between "of" and "records" using regex
     const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
    if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
    } else {
      console.log("Could not find the number in the pagination text.");
    }
    await page.pause();
  
  });*/



