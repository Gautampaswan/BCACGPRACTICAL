

//Test case :296943


const { test, expect } = require('@playwright/test');
let webContext;
// this code is about to login in linkedin
test.beforeAll(async ({ browser }) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    //session injection
    webContext = await browser.newContext({ storageState: 'Dispatch.json' });
    

    await page.close();
});
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

test('Verify that if the user selects the filter for “Today”, then user should be able to view the search result as per the filter selected in "ALL Flights"', async () => {
  const page = await webContext.newPage();
  await page.goto('https://aismartpprd.airindia.com');
  await page.waitForSelector('text=Email Id*')
  await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  await page.waitForTimeout(3000)
  await page.getByRole('button', { name: 'Sign In' }).click();
  await page.waitForTimeout(15000)

  await page.waitForLoadState("networkidle");
  await page.getByText('Dispatch Module').first().dblclick();
  await page.waitForLoadState("networkidle");
  await page.waitForTimeout(10000)
  //await page.getByText('Dispatch Module').first().dblclick();

  await page.waitForURL('https://aismartpprd.airindia.com/DispatchModule');

   
  await page.waitForTimeout(3000);
  await page.waitForSelector('[id="flight-tab-2"]');
  await page.locator('[id="flight-tab-2"]').first().click();
  await page.waitForTimeout(3000);

  await page.locator('div span img[alt="Not Found"]').first().click();
  await page.waitForTimeout(3000);

  await page.getByRole('link', { name: 'Today' }).click();
  await expect.soft(page.getByRole('main')).toContainText('Today');
 const Total_Flights =await page.locator('[class="card-inner"]  h6 ').first().allTextContents();
console.log(Total_Flights);

});

test('Verify that if the user selects the filter for “Yesterday”, then user should be able to view the search result as per the filter selected in "All Flights"', async () => {
  const page = await webContext.newPage();
  const response = await page.goto('https://aismartpprd.airindia.com');
  await page.waitForTimeout(3000);
  // await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  // await page.getByRole('button', { name: 'Sign In' }).click();
  // await page.waitForTimeout(3000)
  await page.goto('https://aismartpprd.airindia.com/DispatchModule');
  await page.waitForTimeout(3000);
  await page.waitForSelector('[id="flight-tab-2"]');
  await page.locator('[id="flight-tab-2"]').first().click();
  await page.waitForTimeout(3000);

  await page.locator('div span img[alt="Not Found"]').first().click();
  await page.waitForTimeout(3000);

  await page.getByRole('link', { name: 'Yesterday' }).click();
  await expect.soft(page.getByRole('main')).toContainText('Yesterday');
  const Total_Flights =await page.locator('[class="card-inner"]  h6 ').first().allTextContents();
  console.log(Total_Flights);
});


test('Verify that if the user selects the filter for “Tomorrow”, then user should be able to view the search result as per the filter selected in "All Flight', async () => {
  const page = await webContext.newPage();
  const response = await page.goto('https://aismartpprd.airindia.com');
  await page.waitForTimeout(3000);
  // await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  // await page.getByRole('button', { name: 'Sign In' }).click();
  // await page.waitForTimeout(3000)
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
  await page.waitForTimeout(3000);
  await page.waitForSelector('[id="flight-tab-2"]');
  await page.locator('[id="flight-tab-2"]').first().click();
  await page.waitForTimeout(3000);

  await page.locator('div span img[alt="Not Found"]').first().click();
  await page.waitForTimeout(3000);

  await page.getByRole('link', { name: 'Tomorrow' }).click();
  await expect.soft(page.getByRole('main')).toContainText('Tomorrow');
  const Total_Flights =await page.locator('[class="card-inner"]  h6 ').first().allTextContents();
  console.log(Total_Flights);

});

test('Verify that if the user selects the filter for “Last 7 days”, then user should be able to view the search result as per the filter selected in "All Flights".', async () => {
  const page = await webContext.newPage();
  const response = await page.goto('https://aismartpprd.airindia.com');
  await page.waitForTimeout(3000);
  // await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  // await page.getByRole('button', { name: 'Sign In' }).click();
  // await page.waitForTimeout(3000)
  await page.goto('https://aismartpprd.airindia.com/DispatchModule');
  await page.waitForTimeout(3000);
  await page.waitForSelector('[id="flight-tab-2"]');
  await page.locator('[id="flight-tab-2"]').first().click();
  await page.waitForTimeout(3000);
  await page.locator('div span img[alt="Not Found"]').first().click();
  await page.waitForTimeout(3000);
  await page.getByRole('link', { name: 'Last 7 days' }).click();
  await expect.soft(page.getByRole('main')).toContainText('Last 7 days');
  const Total_Flights =await page.locator('[class="card-inner"]  h6 ').first().allTextContents();
console.log(Total_Flights);
});

test('Verify that if the user selects the filter for “Last 14 days”, then user should be able to view the search result as per the filter selected in "All Flights"', async () => {
  const page = await webContext.newPage();
  const response = await page.goto('https://aismartpprd.airindia.com');
  await page.waitForTimeout(3000);
  // await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  // await page.getByRole('button', { name: 'Sign In' }).click();
  // await page.waitForTimeout(3000)
  await page.goto('https://aismartpprd.airindia.com/DispatchModule');
  await page.waitForTimeout(3000);
  await page.waitForSelector('[id="flight-tab-2"]');
  await page.locator('[id="flight-tab-2"]').first().click();
  await page.waitForTimeout(3000);
  await page.locator('div span img[alt="Not Found"]').first().click();
  await page.waitForTimeout(3000);
  await page.getByRole('link', { name: 'Last 14 days' }).click();
  await expect.soft(page.getByRole('main')).toContainText('Last 14 days');
  const Total_Flights =await page.locator('[class="card-inner"]  h6 ').first().allTextContents();
console.log(Total_Flights);
});

test('Verify that if the user selects the filter for “Custom Date”, then user should be able to view the search result as per the filter selected in "All Flights.', async () => {
  const page = await webContext.newPage();
  const response = await page.goto('https://aismartpprd.airindia.com');
  await page.waitForTimeout(3000);
  // await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  // await page.getByRole('button', { name: 'Sign In' }).click();
  // await page.waitForTimeout(3000)
  await page.goto('https://aismartpprd.airindia.com/DispatchModule');
  await page.waitForTimeout(3000);
  await page.waitForSelector('[id="flight-tab-2"]');
  await page.locator('[id="flight-tab-2"]').first().click();
  await page.waitForTimeout(3000);
  await page.locator('div span img[alt="Not Found"]').first().click();
  await page.waitForTimeout(3000);
  await page.getByRole('link', { name: 'Custom Range' }).click();
  await page.waitForTimeout(3000);
  await page.getByLabel('Choose Sunday, October 20th,').click();
  await page.getByLabel('Choose Sunday, October 20th,').click();
  await page.waitForTimeout(3000);
  await page.getByRole('button', { name: 'Apply' }).click();
  const Total_Flights =await page.locator('[class="card-inner"]  h6 ').first().allTextContents();
  console.log(Total_Flights);
});


//this for ioccc only

test('Verify that if the user selects the filter for  stations “Any one station ” stations then user should be able to view the search result as per the filter selected in "Dispatcher Allocation".', async () => {
  const page = await webContext.newPage();
  const response = await page.goto('https://aismartpprd.airindia.com');
  // await page.waitForTimeout(3000);
  // await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  // await page.waitForTimeout(3000)
  // await page.getByRole('button', { name: 'Sign In' }).click();
  await page.waitForTimeout(3000)
  await page.goto('https://aismartpprd.airindia.com/DispatchModule');
  await page.waitForTimeout(3000);
 
  await page.getByRole('button', { name: 'All Airports' }).click();
await page.getByLabel('All Airports').uncheck();
await page.getByLabel('BLR').check();
const Total_Flights =await page.locator('[class="card-inner"]  h6 ').first().allTextContents();
console.log(Total_Flights);
//await page.pause();

});




//this for ioccc only

test('Verify that if the user selects the filter for  stations “More than one  station ” stations then user should be able to view the search result as per the filter selected in "Dispatcher Allocation".', async () => {
  const page = await webContext.newPage();
  const response = await page.goto('https://aismartpprd.airindia.com');
  await page.waitForTimeout(3000);
  // await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  // await page.waitForTimeout(1000)
  // await page.getByRole('button', { name: 'Sign In' }).click();
  await page.waitForTimeout(3000)
  await page.goto('https://aismartpprd.airindia.com/DispatchModule');
  await page.waitForTimeout(3000);

  await page.getByRole('button', { name: 'All Airports' }).click();
  await page.getByLabel('All Airports').uncheck();
  await page.getByLabel('BLR').check();
  await page.getByLabel('AJL').check();
  const Total_Flights =await page.locator('[class="card-inner"]  h6 ').first().allTextContents();
console.log(Total_Flights);
});

//this for ioccc only

test('Verify that if the user selects the filter for  stations “All  stations ” stations then user should be able to view the search result as per the filter selected in "All Flights"', async () => {
  const page = await webContext.newPage();
  const response = await page.goto('https://aismartpprd.airindia.com');
  await page.waitForTimeout(3000);
  // await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  // await page.waitForTimeout(3000)
  // await page.getByRole('button', { name: 'Sign In' }).click();
  // await page.waitForTimeout(3000)
  await page.goto('https://aismartpprd.airindia.com/DispatchModule');
  await page.waitForTimeout(3000);
 
  await page.getByRole('button', { name: 'All Airports' }).click();
  await page.getByLabel('All Airports').uncheck();
  await page.getByLabel('All Airports').check();

const Total_Flights =await page.locator('[class="card-inner"]  h6 ').first().allTextContents();
console.log(Total_Flights);

});



//this for ioccc only

test('Verify that user is able to see flight card details based the IST time format when user selects IST radio button in "All Flights".', async () => {
  const page = await webContext.newPage();
  const response = await page.goto('https://aismartpprd.airindia.com');
//   await page.waitForSelector('text=Email Id*')
  // await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  // await page.waitForTimeout(3000)
  // await page.getByRole('button', { name: 'Sign In' }).click();
  await page.waitForTimeout(15000)
 
  await page.waitForLoadState("networkidle");
  await page.getByText('Dispatch Module').first().dblclick();
  await page.waitForLoadState("networkidle");
  await page.waitForTimeout(10000)
  await page.waitForURL('https://aismartpprd.airindia.com/DispatchModule');

  await page.waitForLoadState("networkidle");
 
  await page.waitForTimeout(3000);
 
  const locator = await page.locator('[type="radio"][value="IST"]');
  await locator.click();
  // const locator = page.getByLabel('Subscribe to newsletter');
await expect(locator).toBeChecked();

});

//this for ioccc only
test('Verify that user is able to see flight card details based the UTC time format when user selects UTC radio button in "All Flgihts".', async () => {
  const page = await webContext.newPage();
  const response = await page.goto('https://aismartpprd.airindia.com');
//   await page.waitForSelector('text=Email Id*')
  // await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  // await page.waitForTimeout(3000)
  // await page.getByRole('button', { name: 'Sign In' }).click();
  await page.waitForTimeout(10000)

  await page.waitForLoadState("networkidle");
  await page.getByText('Dispatch Module').first().dblclick();
  await page.waitForLoadState("networkidle");
  await page.waitForTimeout(10000)
  await page.waitForURL('https://aismartpprd.airindia.com/DispatchModule');

  await page.waitForLoadState("networkidle");

  const locator = await page.locator('[type="radio"][value="UTC"]');
  await locator.click();

await expect(locator).toBeChecked();

});

test('Verify that user can Search By full flightNo (Ex AI678) in "All Flgihts"', async () => {
  const page = await webContext.newPage();
  const response = await page.goto('https://aismartpprd.airindia.com');
//   await page.waitForSelector('text=Email Id*')
  // await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  // await page.waitForTimeout(3000)
  // await page.getByRole('button', { name: 'Sign In' }).click();
  await page.waitForTimeout(10000)
 
  await page.waitForLoadState("networkidle");
  await page.getByText('Dispatch Module').first().dblclick();
  await page.waitForLoadState("networkidle");
  await page.waitForTimeout(10000)
  await page.waitForURL('https://aismartpprd.airindia.com/DispatchModule');

  await page.waitForLoadState("networkidle");
  await page.getByPlaceholder('Enter Flight No.').type('AI165');
  await page.keyboard.press('Enter');
 
await page.waitForLoadState("networkidle")
await page.waitForTimeout(30000)
await page.waitForLoadState("load")
await page.waitForLoadState('domcontentloaded');
await expect(page.getByText('AI165').first()).toContainText('AI165');
await page.pause();
});

test('Verify that user can Search By partial flightNo (Ex 678) in "All Flgihts".', async () => {
  const page = await webContext.newPage();
  const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
  // await page.waitForSelector('text=Email Id*')
  // await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
  // await page.waitForTimeout(3000)
  // await page.getByRole('button', { name: 'Sign In' }).click();
  await page.waitForTimeout(30000)
  await page.waitForLoadState("networkidle");
  await page.getByText('Dispatch Module').first().dblclick();
  await page.waitForLoadState("networkidle");
  await page.waitForTimeout(10000)
  await page.waitForURL('https://aismartpprd.airindia.com/DispatchModule');
  await page.waitForLoadState("networkidle");
 
  await page.getByPlaceholder('Enter Flight No.').type('AI16');
  await page.keyboard.press('Enter');
  await page.waitForLoadState("networkidle")
  await page.waitForTimeout(10000)
  await page.waitForLoadState("load")
  await page.waitForLoadState('domcontentloaded');

});

test('Verify that user can Search By full TailNo (Ex VT-AXN) in "All Flights".', async () => {
  const page = await webContext.newPage();
  const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
//   await page.waitForSelector('text=Email Id*')
//   await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
//   await page.waitForTimeout(3000)
//   await page.getByRole('button', { name: 'Sign In' }).click();
// await page.waitForTimeout(30000)
await page.waitForLoadState("networkidle");
await page.getByText('Dispatch Module').first().dblclick();
await page.waitForLoadState("networkidle");
await page.waitForTimeout(10000)
await page.waitForURL('https://aismartpprd.airindia.com/DispatchModule');
await page.waitForLoadState("networkidle");
  await page.getByPlaceholder('Enter Flight No.').type('VT-PPH');
  await page.keyboard.press('Enter');
  await page.waitForLoadState("networkidle")
  await page.waitForTimeout(10000)
  await page.waitForLoadState("load")
  await expect(page.getByText('VT-PPH').first()).toContainText('VT-PPH');
  await page.pause();
  
});