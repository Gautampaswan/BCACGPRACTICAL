const { test, expect } = require('@playwright/test');
const { TIMEOUT } = require('dns');
let webContext;

test.beforeAll(async ({ browser }) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    //session injection
    // webContext = await browser.newContext({ storageState: 'jai.json' });
    webContext = await browser.newContext({ storageState: 'Gautam_iocc.json' });
 
    await page.close();
});
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

//Verify that if the user selects the filter for “Today”, then user should be able to view the count result as per the filter selected in "Dispatcher Allocation".
test('Today', async () => {
  
    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(3000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");

    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();

    await page.waitForTimeout(3000);
    await page.locator("img[alt='Not Found']").nth(3).click();
    await page.locator("//a[text()= 'Today']").click();
    await page.waitForTimeout(3000);
 
 
     const paginationLocator = page.locator("div[class='pagePagination d-flex justify-content-between mt-5 ps-2 align-items-center'] div p");
  
    // Get the full text from the pagination element
    const paginationText = await paginationLocator.textContent();
    console.log("Extracted Pagination Text:", paginationText);
 
    // Extract the number between "of" and "records" using regex
    const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
    if (paginationMatch) {
        const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
        console.log("Total Records (from pagination):", totalRecords);
 
        // Locate the element with class 'card-inner' and extract its number
        const cardInnerLocator = page.locator('.card-inner').nth(0);
        const cardInnerText = await cardInnerLocator.textContent();
        console.log("Extracted Card Inner Text:", cardInnerText);
 
        // Extract the number from the 'card-inner' text using regex (assuming it's a number)
        const cardInnerMatch = cardInnerText.match(/(\d+)/);
 
        if (cardInnerMatch) {
            const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
            console.log("Extracted Number (from card-inner):", cardInnerNumber);
 
            // Compare total records and cardInnerNumber
            if (cardInnerNumber === totalRecords) {
                console.log("Numbers match! Test passed.");
            } else {
                console.log("Numbers do not match. Test failed.");
            }
 
            // You can also add an assertion for this comparison if required
            expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
        } else {
            console.log("Could not extract number from 'card-inner'.");
        }ss
    } else {
        console.log("Could not find the number in the pagination text.");
    }
        await page.pause();
 
});

//Verify that if the user selects the filter for “Yesterday”, then user should be able to view the count result as per the filter selected in "Dispatcher Allocation"
test('“Check records for Yesterday”', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");

    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();

    await page.waitForTimeout(3000);
    await page.locator("img[alt='Not Found']").nth(3).click();
    await page.locator("//a[text()= 'Yesterday']").click();
    await page.waitForTimeout(3000);
 
 
     const paginationLocator = page.locator("div[class='pagePagination d-flex justify-content-between mt-5 ps-2 align-items-center'] div p");
  
    // Get the full text from the pagination element
    const paginationText = await paginationLocator.textContent();
    console.log("Extracted Pagination Text:", paginationText);
 
    // Extract the number between "of" and "records" using regex
    const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
    if (paginationMatch) {
        const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
        console.log("Total Records (from pagination):", totalRecords);
 
        // Locate the element with class 'card-inner' and extract its number
        const cardInnerLocator = page.locator('.card-inner').nth(0);
        const cardInnerText = await cardInnerLocator.textContent();
        console.log("Extracted Card Inner Text:", cardInnerText);
 
        // Extract the number from the 'card-inner' text using regex (assuming it's a number)
        const cardInnerMatch = cardInnerText.match(/(\d+)/);
 
        if (cardInnerMatch) {
            const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
            console.log("Extracted Number (from card-inner):", cardInnerNumber);
 
            // Compare total records and cardInnerNumber
            if (cardInnerNumber === totalRecords) {
                console.log("Numbers match! Test passed.");
            } else {
                console.log("Numbers do not match. Test failed.");
            }
 
            // You can also add an assertion for this comparison if required
            expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
        } else {
            console.log("Could not extract number from 'card-inner'.");
        }
    } else {
        console.log("Could not find the number in the pagination text.");
    }
        await page.pause();

});

//Verify that if the user selects the filter for Tomorrow, then user should be able to view the count result as per the filter selected in "Dispatcher Allocation"
test('Tomorrow', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");

    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();

    await page.waitForTimeout(3000);
    await page.locator("img[alt='Not Found']").nth(3).click();
    await page.locator("//a[text()= 'Tomorrow']").click();
    await page.waitForTimeout(3000);
 
 
     const paginationLocator = page.locator("div[class='pagePagination d-flex justify-content-between mt-5 ps-2 align-items-center'] div p");
  
    // Get the full text from the pagination element
    const paginationText = await paginationLocator.textContent();
    console.log("Extracted Pagination Text:", paginationText);
 
    // Extract the number between "of" and "records" using regex
    const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
    if (paginationMatch) {
        const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
        console.log("Total Records (from pagination):", totalRecords);
 
        // Locate the element with class 'card-inner' and extract its number
        const cardInnerLocator = page.locator('.card-inner').nth(0);
        const cardInnerText = await cardInnerLocator.textContent();
        console.log("Extracted Card Inner Text:", cardInnerText);
 
        // Extract the number from the 'card-inner' text using regex (assuming it's a number)
        const cardInnerMatch = cardInnerText.match(/(\d+)/);
 
        if (cardInnerMatch) {
            const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
            console.log("Extracted Number (from card-inner):", cardInnerNumber);
 
            // Compare total records and cardInnerNumber
            if (cardInnerNumber === totalRecords) {
                console.log("Numbers match! Test passed.");
            } else {
                console.log("Numbers do not match. Test failed.");
            }
 
            // You can also add an assertion for this comparison if required
            expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
        } else {
            console.log("Could not extract number from 'card-inner'.");
        }
    } else {
        console.log("Could not find the number in the pagination text.");
    }   await page.pause();
});
//Verify that if the user selects the filter for “Last 7 days”, then user should be able to view the count result as per the filter selected in "Dispatcher Allocation".
test('Last 7 days', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");

    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();

    await page.waitForTimeout(3000);
    await page.locator("img[alt='Not Found']").nth(3).click();
    await page.locator("//a[text()= 'Last 7 days']").click();
    await page.waitForTimeout(3000);
 
 
     const paginationLocator = page.locator("div[class='pagePagination d-flex justify-content-between mt-5 ps-2 align-items-center'] div p");
  
    // Get the full text from the pagination element
    const paginationText = await paginationLocator.textContent();
    console.log("Extracted Pagination Text:", paginationText);
 
    // Extract the number between "of" and "records" using regex
    const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
    if (paginationMatch) {
        const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
        console.log("Total Records (from pagination):", totalRecords);
 
        // Locate the element with class 'card-inner' and extract its number
        const cardInnerLocator = page.locator('.card-inner').nth(0);
        const cardInnerText = await cardInnerLocator.textContent();
        console.log("Extracted Card Inner Text:", cardInnerText);
 
        // Extract the number from the 'card-inner' text using regex (assuming it's a number)
        const cardInnerMatch = cardInnerText.match(/(\d+)/);
 
        if (cardInnerMatch) {
            const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
            console.log("Extracted Number (from card-inner):", cardInnerNumber);
 
            // Compare total records and cardInnerNumber
            if (cardInnerNumber === totalRecords) {
                console.log("Numbers match! Test passed.");
            } else {
                console.log("Numbers do not match. Test failed.");
            }
 
            // You can also add an assertion for this comparison if required
            expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
        } else {
            console.log("Could not extract number from 'card-inner'.");
        }
    } else {
        console.log("Could not find the number in the pagination text.");
    }
        await page.pause();
 
});

//Verify that if the user selects the filter for “Last 14 days”, then user should be able to view the count result as per the filter selected in "Dispatcher Allocation"
test('Last 14 days', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");

    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();

    await page.waitForTimeout(3000);
    await page.locator("img[alt='Not Found']").nth(3).click();
    await page.locator("//a[text()= 'Last 14 days']").click();
    await page.waitForTimeout(3000);
 
 
     const paginationLocator = page.locator("div[class='pagePagination d-flex justify-content-between mt-5 ps-2 align-items-center'] div p");
  
    // Get the full text from the pagination element
    const paginationText = await paginationLocator.textContent();
    console.log("Extracted Pagination Text:", paginationText);
 
    // Extract the number between "of" and "records" using regex
    const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
    if (paginationMatch) {
        const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
        console.log("Total Records (from pagination):", totalRecords);
 
        // Locate the element with class 'card-inner' and extract its number
        const cardInnerLocator = page.locator('.card-inner').nth(0);
        const cardInnerText = await cardInnerLocator.textContent();
        console.log("Extracted Card Inner Text:", cardInnerText);
 
        // Extract the number from the 'card-inner' text using regex (assuming it's a number)
        const cardInnerMatch = cardInnerText.match(/(\d+)/);
 
        if (cardInnerMatch) {
            const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
            console.log("Extracted Number (from card-inner):", cardInnerNumber);
 
            // Compare total records and cardInnerNumber
            if (cardInnerNumber === totalRecords) {
                console.log("Numbers match! Test passed.");
            } else {
                console.log("Numbers do not match. Test failed.");
            }
 
            // You can also add an assertion for this comparison if required
            expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
        } else {
            console.log("Could not extract number from 'card-inner'.");
        }
    } else {
        console.log("Could not find the number in the pagination text.");
    }
        await page.pause();
 
});

//Verify that if the user selects the filter for  stations “Any one station ” then user should be able to view the count result as per the filter selected in "Dispatcher Allocation".
test('SelectAny Station', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");

        //Click on Allocate dispatcher tab
        await page.waitForTimeout(3000);
        const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
        await allocateDispatcher.click();
        await page.waitForTimeout(3000);
        const dropdownicon = await page.locator(".dpArrows img");
        await dropdownicon.click();
        //Uncheck All Airport option
        const uncheckAllairport = await page.getByLabel('All Airports')//uncheck();
        await uncheckAllairport.uncheck();
        //Select any Station from dropdown
        const checkAnystation = await page.getByLabel('BLR');
        await checkAnystation.click();

        //Check if station counts are equal or not
        await page.waitForTimeout(3000);
        const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");

        // Get the full text from the pagination element
        await page.waitForTimeout(3000);
        const paginationText = await paginationLocator.textContent();
        console.log("Extracted Pagination Text:", paginationText);

        // Extract the number between "of" and "records" using regex
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
        if (paginationMatch) {
        const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
        console.log("Total Records (from pagination):", totalRecords);


        // Locate the element with class 'card-inner' and extract its number
        const cardInnerLocator = page.locator('.card-inner').nth(0);
        const cardInnerText = await cardInnerLocator.textContent();
        console.log("Extracted Card Inner Text:", cardInnerText);

        // Extract the number from the 'card-inner' text using regex (assuming it's a number)
        const cardInnerMatch = cardInnerText.match(/(\d+)/);

        if (cardInnerMatch) {
        const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
        console.log("Extracted Number (from card-inner):", cardInnerNumber);

        // Compare total records and cardInnerNumber
        if (cardInnerNumber === totalRecords) {
            console.log("Numbers match! Test passed.");
        } else {
            console.log("Total Flights matched do not match. Test failed.");
        }

        // You can also add an assertion for this comparison if required
        expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
    } else {
        console.log("Could not extract number from 'card-inner'.");
    }
} else {
    console.log("Could not find the number in the pagination text.");
} await page.pause();

});

//Verify that if the user selects the filter for  stations “More than one  station ” stations then user should be able to view the count result as per the filter selected in "Dispatcher Allocation"
test('Morethan one Station', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");
  
    //Click on Allocate dispatcher tab
    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();
    await page.waitForTimeout(3000);
     const dropdownicon = await page.locator(".dpArrows img");
     await dropdownicon.click();

     //Uncheck All Airport option
     await page.waitForTimeout(3000);
     const uncheckAllairport = await page.getByLabel('All Airports')//uncheck();
     await uncheckAllairport.uncheck();

     //Select any Station from dropdown
     const checkAnystation = await page.getByLabel('BLR');
     await checkAnystation.click();

     await page.waitForTimeout(3000);
     const checkTwostations = await page.getByLabel('GAU')
     await checkTwostations.click();

    //Check if station counts are equal or not
      await page.waitForTimeout(3000);
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
        // Get the full text from the pagination element
            const paginationText = await paginationLocator.textContent();
            console.log("Extracted Pagination Text:", paginationText);
  
            // Extract the number between "of" and "records" using regex
            const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
            if (paginationMatch) {
            const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
            console.log("Total Records (from pagination):", totalRecords);
  
  
            // Locate the element with class 'card-inner' and extract its number
            const cardInnerLocator = page.locator('.card-inner').nth(0);
            const cardInnerText = await cardInnerLocator.textContent();
            console.log("Extracted Card Inner Text:", cardInnerText);
  
            // Extract the number from the 'card-inner' text using regex (assuming it's a number)
            const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
        await page.pause();
  
  });

  //Verify that if the user selects the filter for  stations “All  stations ” stations then user should be able to view the count result as per the filter selected in "Dispatcher Allocation"
  test('Select All Stations', async () => {

    const page = await webContext.newPage();
    //await page.pause();
    const response = await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForLoadState('domcontentloaded');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await page.waitForTimeout(3000);
    await page.waitForLoadState('load');
    //await page.waitForLoadState("networkidle")
    await page.waitForTimeout(30000)
    //await page.waitForLoadState("load")
    await page.waitForLoadState('domcontentloaded');
    await page.goto('https://aismartpprd.airindia.com/DispatchModule');
    await page.waitForTimeout(3000);
    console.log("Dispatch Module Dashboard has been opened");
  
  
    //Click on Allocate dispatcher tab
    await page.waitForTimeout(3000);
    const allocateDispatcher = await page.locator("//button[text()= 'Allocate Dispatchers']");
    await allocateDispatcher.click();

    await page.waitForTimeout(3000);
    const dropdownicon = await page.locator(".dpArrows img");
     await dropdownicon.click();

    //Check if station counts are equal or not
      await page.waitForTimeout(3000);
      const paginationLocator = page.locator("#root > div > main > div.dispatchModuleDesktop > div > section.flight_list > div.container-fluid > div > div.pagePagination.d-flex.justify-content-between.mt-5.ps-2.align-items-center > div > p");
  
        // Get the full text from the pagination element
        const paginationText = await paginationLocator.textContent();
        console.log("Extracted Pagination Text:", paginationText);
  
        // Extract the number between "of" and "records" using regex
        const paginationMatch = paginationText.match(/of\s(\d+)\srecords/);
        if (paginationMatch) {
      const totalRecords = parseInt(paginationMatch[1]); // Convert to an integer
      console.log("Total Records (from pagination):", totalRecords);
  
  
      // Locate the element with class 'card-inner' and extract its number
      const cardInnerLocator = page.locator('.card-inner').nth(0);
      const cardInnerText = await cardInnerLocator.textContent();
      console.log("Extracted Card Inner Text:", cardInnerText);
  
      // Extract the number from the 'card-inner' text using regex (assuming it's a number)
      const cardInnerMatch = cardInnerText.match(/(\d+)/);
  
      if (cardInnerMatch) {
          const cardInnerNumber = parseInt(cardInnerMatch[1]); // Convert to an integer
          console.log("Extracted Number (from card-inner):", cardInnerNumber);
  
          // Compare total records and cardInnerNumber
          if (cardInnerNumber === totalRecords) {
              console.log("Numbers match! Test passed.");
          } else {
              console.log("Total Flights matched do not match. Test failed.");
          }
  
          // You can also add an assertion for this comparison if required
          expect(cardInnerNumber).toBe(totalRecords); // Passes if they match, fails if not
      } else {
          console.log("Could not extract number from 'card-inner'.");
      }
  } else {
      console.log("Could not find the number in the pagination text.");
  }
     await page.pause();
  
  
  });



 