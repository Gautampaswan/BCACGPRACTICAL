const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../POM/LoginPage');
const { allocateDispatch } = require('../POM/allocateDispatch');//stationFilterForDispatcher
const { stationFilterForDispatcher } = require('../POM/stationFilterForDispatcher');
const { allocateDispSearchBYTF } = require('../POM/allocateDispSearchBYTF');

let webContext;

//Object for Date filter
let allocateDispatcher;

//Object for Station Filter
let dispatcherTabforStationFilter;

//Object for Tail and flight search
let countTailandFlightNum;

//let allocateDispatch

test.beforeAll(async ({ browser }) => {

    // session injection

    webContext = await browser.newContext({ storageState: 'dev2IOCC.json' });

    const page = await webContext.newPage();

    // Create an instance of LoginPage and login once

    const loginPage = new LoginPage(page);

    //await loginPage.goto(); // Navigate to the main page

    await loginPage.navigate('https://aismartdev2.airindia.com/'); // Navigate to the login page

    await loginPage.login('app.monitoring@airindia.com'); // Perform login
 
    //initialize allocateDispatch class
    allocateDispatcher                = new allocateDispatch(page);

    //initialize stationFilterForDispatcher class
    dispatcherTabforStationFilter      = new stationFilterForDispatcher(page);

    //initialize allocateDispSearchBYTF class
    countTailandFlightNum               = new allocateDispSearchBYTF(page);


    await allocateDispatcher.openDashboard();

    await allocateDispatcher.clickdispatchModuleForDispatcherTab()

    await allocateDispatcher.clickAllocateDispatcherTab();
 

});

//**********************Test Date Filter for Allocate Dispatcher Tab**************//

 const filters = [

    { name: 'Today', method: 'selectFilterforToday' },

    { name: 'Tomorrow', method: 'selectFilterforTomorrow' },

    { name: 'Yesterday', method: 'selectFilterforYesterday' },

    { name: 'Last 7 days', method: 'selectFilterforLast7Days' },

    //{ name: 'Last 14 days', method: 'selectFilterforLast14Days' },

];
 
// Loop through each filter and run tests

filters.forEach(filter => {

    test(`Filter "${filter.name}" should display the correct count of flights`, async () => {

        // Apply the filter dynamically based on the filter method

        await allocateDispatcher[filter.method]();
 
        // Validate flight counts//allocateDispatcher

        const { totalRecords, cardInnerNumber } = await allocateDispatcher.validateFlightCount();

        if (totalRecords && cardInnerNumber) {

            expect(cardInnerNumber).toBe(totalRecords);

            console.log(`Filter "${filter.name}": Numbers match! Test passed.`);

        } else {

            console.log(`Filter "${filter.name}": Test failed. Could not validate flight counts.`);

        }

    });

});

    test('Test Date filter functionality for !4 days For Allocate Dispatcher', async() =>{

        await allocateDispatcher.selectFilterforLast14Days();
    });



//*************************                                       ************************************//
//*************************Station Filter for "Allocate dispatcher"***********************************//

const filterActions = [   
    { name: 'One Station', method: 'selectCheckboxForOneStation' },

    { name: 'Multiple Stations', method: 'filtersmorethanoneStation' },

    { name: 'All Stations', method: 'selectFiltersforallStations' }
 ];

filterActions.forEach(filter => {     
test(`Filter "${filter.name}" should display the correct count of flights`, async () => {         
    await dispatcherTabforStationFilter[filter.method]();        
    const { totalRecords, cardInnerNumber } = await dispatcherTabforStationFilter.validateFlightCount(); 

    if (totalRecords && cardInnerNumber) {    

        expect(cardInnerNumber).toBe(totalRecords); 

    console.log(`Filter "${filter.name}": Numbers match! Test passed`); } else { 
    console.log(`Filter "${filter.name}": Test failed. Could not validate flight counts.`); 

} });

});


//************Search By Tail and Flight number for Allocate dispatcher****************//

test('Seacrh with full flight number', async ()=>
    {
       
        //const stationfiltersPage = new flightsCountforstationFilter(page);
        await countTailandFlightNum.searchByfullFlightNumberForallocateDispatcher();
    
        const { totalRecords, cardInnerNumber } = await countTailandFlightNum.validateFlightCount();
        if (totalRecords && cardInnerNumber) {
            expect(cardInnerNumber).toBe(totalRecords);
            console.log("Numbers match! Test passed.");
        } else {
            console.log("Test failed. Could not validate flight counts.");
        }
    
    });

    test('Seacrh with Half flight number', async ()=>
        {
           
            //const stationfiltersPage = new flightsCountforstationFilter(page);
            await countTailandFlightNum.searchByHalfFlightNumberForallocateDispatcher();
        
            const { totalRecords, cardInnerNumber } = await countTailandFlightNum.validateFlightCount();
            if (totalRecords && cardInnerNumber) {
                expect(cardInnerNumber).toBe(totalRecords);
                console.log("Numbers match! Test passed.");
            } else {
                console.log("Test failed. Could not validate flight counts.");
            }
        
        });
    



    test('Seacrh with full tail number', async ()=>{

        await countTailandFlightNum.seacrhByfullTailNumberForAllocateDispatcher();
    
        const { totalRecords, cardInnerNumber } = await countTailandFlightNum.validateFlightCount();
        if (totalRecords && cardInnerNumber) {
            expect(cardInnerNumber).toBe(totalRecords);
            console.log("Numbers match! Test passed.");
        } else {
            console.log("Test failed. Could not validate flight counts.");
        }
    
    
    });


    test('Seacrh with Half tail number', async ()=>{

        await countTailandFlightNum.seacrhByHalfTailNumberForAllocateDispatcher();
    
        const { totalRecords, cardInnerNumber } = await countTailandFlightNum.validateFlightCount();
        if (totalRecords && cardInnerNumber) {
            expect(cardInnerNumber).toBe(totalRecords);
            console.log("Numbers match! Test passed.");
        } else {
            console.log("Test failed. Could not validate flight counts.");
        }
    
    
    });
    


   