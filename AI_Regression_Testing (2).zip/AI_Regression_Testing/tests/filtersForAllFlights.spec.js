const { test, expect } = require('@playwright/test');

const { LoginPage } = require('../POM/LoginPage');

const { DashboardPage } = require('../POM/DashboardPage');

const { flightsCountforstationFilter } = require('../POM/flightsCountforstationFilter');

const { searchbyTailandFilghtNumber } = require('../POM/searchbyTailandFilghtNumber');

//searchbyTailandFilghtNumber
 
let webContext;

let dashboardPage;

let stationfiltersPage;

let flightsearchBox;

//let loginPage;
 
test.beforeAll(async ({ browser }) => {

    // session injection

    webContext = await browser.newContext({ storageState: 'dev2IOCC.json' });

    const page = await webContext.newPage();

    // Create an instance of LoginPage and login once

    const loginPage = new LoginPage(page);

    

    // await loginPage.goto(); // Navigate to the main page

     await loginPage.navigate('https://aismartdev2.airindia.com'); // Navigate to the login page

     await loginPage.login('app.monitoring@airindia.com');   // Perform login
 
    // Create an instance of DashboardPage after successful login

    dashboardPage       =    new DashboardPage(page);

    stationfiltersPage  =     new flightsCountforstationFilter(page);

    flightsearchBox     =     new searchbyTailandFilghtNumber(page);
 
    // Ensure we are on the dashboard page before starting tests

    //  await dashboardPage.openDashboard();
    // //Ckick on dispatchmodule for date filter
      await dashboardPage.clickDispatchModuleAllFlights();
   
});

/*test('Test Filter for Today', async() =>{
   
await dashboardPage.selectFilterToday();
await dashboardPage.validateFlightCountSecond();

});

 
test('Test Filter for Tommorrow', async() =>{
    
    await dashboardPage.selectFilterTomorrow();
    await dashboardPage.validateFlightCountSecond();



});


test('Test Filter for Yesterday', async() => {
    
    await dashboardPage.selectFilterYesterday();
    await dashboardPage.validateFlightCountSecond();


   

});

test('Test Filter for 7 days', async() => {
    
    await dashboardPage.selectFilterLast7Days();
    await dashboardPage.validateFlightCountSecond();


   
});*/





//********************For Date Filter*****************************//
// Define an array of filter details to be tested

const filters = [

    { name: 'Today', method: 'selectFilterToday' },

    { name: 'Tomorrow', method: 'selectFilterTomorrow' },

    { name: 'Yesterday', method: 'selectFilterYesterday' },

    { name: 'Last 7 days', method: 'selectFilterLast7Days' },

    //{ name: 'Last 14 days', method: 'selectFilterLast14Days' },

];
 
// Loop through each filter and run tests

filters.forEach(filter => {

    test(`Filter "${filter.name}" should display the correct count of flights`, async () => {

        // Apply the filter dynamically based on the filter method

        await dashboardPage[filter.method]();
 
        // Validate flight counts

        const { totalRecords, cardInnerNumber } = await dashboardPage.validateFlightCount();

        if (totalRecords && cardInnerNumber) {

            expect(cardInnerNumber).toBe(totalRecords);

            console.log(`Filter "${filter.name}": Numbers match! Test passed.`);

        } else {

            console.log(`Filter "${filter.name}": Test failed. Could not validate flight counts.`);

        }

    });

});


test('Test Date filter for 14 days', async() =>{

    await dashboardPage.selectFilterLast14Days();
});

////////////////////////////Functionality for Station Filter//////////////////////////////

    const filterActions = [   
        { name: 'One Station', method: 'clickonOneStation' },

        { name: 'Multiple Stations', method: 'morethanOneStation' },

        { name: 'All Stations', method: 'allStations' }
     ];

    filterActions.forEach(filter => {     
    test(`Filter "${filter.name}" should display the correct count of flights`, async () => {         await stationfiltersPage[filter.method]();        
        const { totalRecords, cardInnerNumber } = await stationfiltersPage.validateFlightCount(); 

        if (totalRecords && cardInnerNumber) {    

            expect(cardInnerNumber).toBe(totalRecords); 

        console.log(`Filter "${filter.name}": Numbers match! Test passed`); } else { 
        console.log(`Filter "${filter.name}": Test failed. Could not validate flight counts.`); 
    
    } });

});

//////////////////////////////////////Search with full flight number//////////////////

test('Seacrh with full flight number', async ()=>
{
   
    await flightsearchBox.searchByfullFlightNumber();

    const { totalRecords, cardInnerNumber } = await flightsearchBox.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }

});

// Search By half Flight Number//
test('Seacrh with Half flight number', async ()=>
    {
       
        await flightsearchBox.searchByHalfFlightNumber();
    
        const { totalRecords, cardInnerNumber } = await flightsearchBox.validateFlightCount();
        if (totalRecords && cardInnerNumber) {
            expect(cardInnerNumber).toBe(totalRecords);
            console.log("Numbers match! Test passed.");
        } else {
            console.log("Test failed. Could not validate flight counts.");
        }
    
    });


// Search By Full tail number//
test('Seacrh with full tail number', async ()=>{

    await flightsearchBox.seacrhByfullTailNumber();

    const { totalRecords, cardInnerNumber } = await flightsearchBox.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }


});

// Search By Half Tail Number//
test('Seacrh with half tail number', async ()=>{

    await flightsearchBox.seacrhByHalfTailNumber();

    const { totalRecords, cardInnerNumber } = await flightsearchBox.validateFlightCount();
    if (totalRecords && cardInnerNumber) {
        expect(cardInnerNumber).toBe(totalRecords);
        console.log("Numbers match! Test passed.");
    } else {
        console.log("Test failed. Could not validate flight counts.");
    }


});


 


















// Define an array of filter details to be tested
/*const stationFilters = [
    { description: 'Single Station: BLR', stations: ['BLR'] },
    { description: 'Multiple Stations: BLR, GAU', stations: ['BLR', 'GAU'] },
    { description: 'All Stations', stations: [] } // Empty array for "All Stations" case
];*/
 
// Loop through each filter scenario and run tests
/*stationFilters.forEach(filter => {
    test.only(`Filter for "${filter.description}" should display the correct count of flights`, async () => {
        // Apply the station filter dynamically based on the provided stations
        await stationfiltersPage.applyStationFilter(filter.stations);
 
        // Validate flight counts
        const { totalRecords, cardInnerNumber } = await stationfiltersPage.validateFlightCount();
        if (totalRecords && cardInnerNumber) {
            expect(cardInnerNumber).toBe(totalRecords);
            console.log(`Filter for "${filter.description}": Numbers match! Test passed.`);
        } else {
            console.log(`Filter for "${filter.description}": Test failed. Could not validate flight counts.`);
        }
    });
});*/




















 