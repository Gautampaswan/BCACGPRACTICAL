const { test, expect } = require('@playwright/test');
//const authFile = 'playwright/.auth/user.json';
let webContext;
 

//const { LoginPage } = require('../POM/LoginPage'); // Update with the correct path
 
test.beforeAll('Store login session', async ({ browser }) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    
    await page.goto('https://aismartdev2.airindia.com/');
    await page.getByLabel('Email Id*').fill('app.monitoring@airindia.com');
    //await page.getByLabel('Password').fill('password');
    await page.getByRole('button', { name: 'Sign in' }).click();
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(60000);
     await context.storageState({path: 'dev2IOCC.json'});


    webContext = await browser.newContext({storageState:'dev2IOCC.json'});
    
});

test('test', async({browser}) => {


// //const context = await browser.newContext();
// const page = await webContext.newPage();

 await await page.waitForTimeout(30000);
// await page.goto('https://aismartdev2.airindia.com');




});