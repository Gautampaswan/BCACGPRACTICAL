const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../POM/LoginPage');
const { istAndUTCdata } = require('../POM/istAndUTCdata');//istAndUTCdata




let webContext;
let valIStUTCTime;

test.beforeAll(async ({ browser }) => {//editFICandADC

    // session injection

    webContext = await browser.newContext({ storageState: 'dev2IOCC.json' });

    const page = await webContext.newPage();

    // Create an instance of LoginPage and login once

    const loginPage = new LoginPage(page);

    valIStUTCTime = new istAndUTCdata(page);

    await loginPage.navigate('https://aismartdev2.airindia.com/'); // Navigate to the login page

    await loginPage.login('app.monitoring@airindia.com'); // Perform login

});

    test('Validate IST data and UTC data', async() =>{

        await valIStUTCTime.verifyFlightsDetail();


    });