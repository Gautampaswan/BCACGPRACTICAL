const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../POM/LoginPage');
const { firstOfficerDetail } = require('../POM/firstOfficerDetail');
const { captainDetail } = require('../POM/captainDetail');

//Define webContext
let webContext;
//define object for firstOfficerDetail class
let firstOfficerObject;

//Define object for firstOfficerDetail class
let captainObject;


test.beforeAll(async ({ browser }) => {

    // session injection

    webContext = await browser.newContext({ storageState: 'dev2IOCC.json' });

    const page = await webContext.newPage();

    // Create an instance of LoginPage and login once

    const loginPage = new LoginPage(page);

    //Initialize firstOfficerDetail class
    firstOfficerObject = new firstOfficerDetail(page); //firstOffAndCaptainCrewDetail

    //Initialize captainDetail class
    captainObject     = new captainDetail(page);

    //await loginPage.goto(); // Navigate to the main page

    await loginPage.navigate('https://aismartdev2.airindia.com/'); // Navigate to the login page

    await loginPage.login('app.monitoring@airindia.com'); // Perform login


});

//*******************************************************************************************//
    test('Test Crew Details functionality for first Officer', async() => {

       
        await firstOfficerObject.clickFirstOffMoreButton();

    });

//********************************************************************************************//
test('Test Rooster Detail functionality for First Officer', async() => {
    await firstOfficerObject.clickFirstOffmoreButtonAndClickRoosterDetail();

});

//*******************************************************************************************//

    test('Test Crew Details functionality for Captain', async() => {
        
        await captainObject.crewDetailsForCaptain();
        
    });

//*******************************************************************************************//


test('Test rooster functionality for Captain', async() => {
        
    await captainObject.roosterDetailForCaptain();
    
});